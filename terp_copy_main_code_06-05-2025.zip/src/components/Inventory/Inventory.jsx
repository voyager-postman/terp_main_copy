const Inventory = () => {
	return <div>Inventory</div>
}

export default Inventory
