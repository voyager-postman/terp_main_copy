import axios from "axios";
import { useEffect, useMemo, useState } from "react";
import Barcode from "react-barcode";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { TableView } from "../table";

const CombinePayment = () => {
  const formatterTwo = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const [data, setData] = useState([]);
  const [isOn, setIsOn] = useState(true);
  const navigate = useNavigate();

  const getCombinedPayment = () => {
    axios
      .get(`${API_BASE_URL}/getCombinedPayment`)
      .then((response) => {
        console.log(response);
        setData(response.data.data || []);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    getCombinedPayment();
  }, []);

  const updateEanStatus = (eanID) => {
    const request = {
      ean_id: eanID,
    };

    axios
      .post(`${API_BASE_URL}/eanStatus`, request)
      .then((resp) => {
        // console.log(resp, "Check Resp")
        if (resp.data.success == true) {
          toast.success("Status Updated Successfully", {
            autoClose: 1000,
            theme: "colored",
          });
          getCombinedPayment();
          return;
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const columns = useMemo(
    () => [
      {
        Header: "Cpn code",
        accessor: "CPNCODE",
      },

      {
        Header: "Vendor",
        accessor:"vendor_name",
      },

      {
        Header: "Date",
        accessor: (a) => {
          const formattedDate = new Date(a.CPN_Date).toLocaleDateString(
            "en-GB",
            {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
            }
          );

          return <div>{formattedDate}</div>;
        },
      },

      {
        Header: "Due date",
        accessor: (a) => {
          const formattedDate = new Date(a.Due_Date).toLocaleDateString(
            "en-GB",
            {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
            }
          );

          return <div>{formattedDate}</div>;
        },
      },
      {
        Header: "POs",
        accessor: (a) => <div>{a.POCount}</div>,
      },

      {
        Header: "Amount",
        accessor: (a) => (
          <div style={{ textAlign: "right" }}>
            {formatterTwo.format(a.Payment_amount)}
          </div>
        ),
      },

      {
        Header: "Payable",
        accessor: (a) => (
          <div style={{ textAlign: "right" }}>
            {formatterTwo.format(a.Payable)}
          </div>
        ),
      },
      // {
      //   Header: "Status",
      //   accessor: (a) => (
      //     <label
      //       style={{
      //         display: "flex",
      //         justifyContent: "center",
      //         alignItems: "center",
      //         marginTop: "10px",
      //       }}
      //       className="toggleSwitch large"
      //     >
      //       <input
      //         checked={a.Available == "1" ? true : false}
      //         onChange={() => {
      //           setIsOn(!isOn);
      //         }}
      //         onClick={() => updateEanStatus(a.ID)}
      //         value={a.Available}
      //         type="checkbox"
      //       />
      //       <span>
      //         <span>OFF</span>
      //         <span>ON</span>
      //       </span>
      //       <a></a>
      //     </label>
      //   ),
      // },

      {
        Header: "Actions",
        accessor: (a) => (
          <div className="editIcon">
            <button
              onClick={() =>
                navigate("/combinePaymentView", { state: { from: a } })
              }
            >
              <i className="mdi mdi-eye" />
            </button>
            <Link to="/combinePaymenEdit" state={{ from: a }}>
              <i className="mdi mdi-pencil pl-2" />
            </Link>

            <button type="button" onClick={() => deleteOrder(a.PO_ID)}>
              <i className="ps-2 mdi mdi-delete" />
            </button>

            <button
              type="button"
              className="SvgAnchor"
              data-bs-toggle="modal"
              data-bs-target="#modalCombine"
            >
              <svg
                className="SvgQuo"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
              >
                <title>cash-check</title>
                <path d="M3 6V18H13.32C13.1 17.33 13 16.66 13 16H7C7 14.9 6.11 14 5 14V10C6.11 10 7 9.11 7 8H17C17 9.11 17.9 10 19 10V10.06C19.67 10.06 20.34 10.18 21 10.4V6H3M12 9C10.3 9.03 9 10.3 9 12C9 13.7 10.3 14.94 12 15C12.38 15 12.77 14.92 13.14 14.77C13.41 13.67 13.86 12.63 14.97 11.61C14.85 10.28 13.59 8.97 12 9M21.63 12.27L17.76 16.17L16.41 14.8L15 16.22L17.75 19L23.03 13.68L21.63 12.27Z" />
              </svg>
            </button>
          </div>
        ),
      },

      // {
      //   Header: "Salary",
      //   accessor: (a) => <>{"10000000"}</>,
      // },
    ],
    []
  );

  return (
    <Card
      title={"Combined Payment  Management"}
      endElement={
        <button
          type="button"
          onClick={() => navigate("/combinePaymenEdit")}
          className="btn button btn-info"
        >
          Create
        </button>
      }
    >
      <TableView columns={columns} data={data} />
    </Card>
  );
};

export default CombinePayment;
