import React from "react";
import { useQuery } from "react-query";
import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { TableView } from "../table";

const Receiving = () => {
  const navigate = useNavigate();

  const [data, setData] = useState([]);
  useEffect(() => {
    axios.get(`${API_BASE_URL}/getViewToReceving`).then((res) => {
      setData(res.data.data || []);
    });
  }, []);
  // const { data } = useQuery("getViewToReceving");
  console.log(data);
  const columns = React.useMemo(
    () => [
      {
        Header: "Code",
        accessor: "PODCODE",
      },
      {
        Header: "Vender Name",
        accessor: "Vendor_Name",
      },
      {
        Header: "Name",
        accessor: "Name_EN",
      },

      {
        Header: "Purchase Date",
        accessor: (r) => new Date(r.PO_date).toLocaleDateString(),
      },
      {
        Header: "Crates",
        accessor: "Crates",
      },
      {
        Header: "Quantity",
        accessor: "Quantity",
      },
      {
        Header: "Unit",
        accessor: "Unit_Name",
      },
      {
        Header: "Price",
        accessor: "Inventory_entry",
      },
      {
        Header: "Actions",
        accessor: (a) => (
          <>
            <Link state={{ from: a }} to="/acceptreceiving">
              <i
                className="mdi mdi-check"
                style={{
                  width: "20px",
                  color: "#203764",
                  fontSize: "22px",
                  marginTop: "10px",
                }}
              />
            </Link>
            {/* <button type="button">
              <i
                className="mdi mdi-restore"
                style={{
                  width: "20px",
                  color: "#203764",
                  fontSize: "22px",
                  marginTop: "10px",
                }}
              />
            </button> */}
          </>
        ),
      },
    ],
    []
  );
  return (
    <Card title="Receive Management">
      <TableView columns={columns} data={data} />
    </Card>
  );
};

export default Receiving;
