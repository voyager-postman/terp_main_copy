import axios from "axios";
import React, { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { ComboBox } from "../combobox";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import { Button, Modal } from "react-bootstrap";
import CloseIcon from "@mui/icons-material/Close";

const CreatePurchaseOrder = () => {
  const [buttonClicked, setButtonClicked] = React.useState(false);
  const location = useLocation();
  const [dropdownItems, setDropdownItems] = useState([]);
  const { from } = location.state || {};
  console.log(from);
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [stock, setStock] = useState("");
  const [color, setColor] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [details, setDetails] = React.useState([]);
  const getDetils = () => {
    if (from?.PO_ID) {
      axios
        .get(`${API_BASE_URL}/getPurchaseOrderDetails?po_id=${from?.PO_ID}`)
        .then((response) => {
          console.log(response);

          const mappedData = response.data.data.map((item) => ({
            pod_status: item.Receiving_Status,
            pod_id: item.POD_ID,
            pod_code: item.PODCODE,
            dropDown_id: item.POD_Items_ID,
            produce_name_en: item.Name_EN,
            pod_quantity: item.Qty,
            unit_count_id: item.Unit,
            pod_price: item.pod_price,
            pod_vat: item.VAT,
            pod_wht_id: item.WHT,
            pod_crate: item.Crates,
          }));
          setDetails(mappedData);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };
  const closeIcon = () => {
    setShow(false);
    navigate("/purchase_orders");
  };
  const handleEditDatils = (i, e) => {
    const newEditPackaging = [...details];
    newEditPackaging[i][e.target.name] = e.target.value;
    setDetails(newEditPackaging);
  };
  // const itemData1 = async () => {
  //   try {
  //     const response = await axios.post(
  //       `${API_BASE_URL}/PurchaseTypeItemsList`
  //     );
  //     setDropdownItems(response.data.data || []);
  //   } catch (error) {
  //     console.error("Error fetching purchase type items:", error);
  //   }
  // };
  // useEffect(() => {
  //   itemData1();
  // }, []);
  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const response = await axios.post(
          `${API_BASE_URL}/PurchaseTypeItemsList`
        );
        console.log(response.data);
        setOptionItem(response.data.data); // Assuming data is already an array of objects
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchOptions();
  }, []);
  useEffect(() => {
    const fetchUnits = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/getAllUnit`);
        console.log("API Response:", response.data.data);

        // Assuming response.data.data is the correct array
        setUnitItem(response.data.data || []);
      } catch (error) {
        console.error("Error fetching units:", error);
        setUnitItem([]); // Fallback to an empty array
      }
    };

    fetchUnits();
  }, []);
  const deleteDetails = async (pod_id) => {
    try {
      await axios.post(`${API_BASE_URL}/deletePurchaseOrderDetails`, {
        pod_id: pod_id,
      });
      toast.success("Deleted Successfully", {
        autoClose: 1000,
        theme: "colored",
      });
      getDetils();
    } catch (e) {}
  };

  const [state, setState] = React.useState({
    po_id: from?.PO_ID,
    vendor_id: from?.Vendor,
    vendor_name: from?.Vendor_name,
    created: from?.created || "0000-00-00",
    // `${new Date().getFullYear()}-${new Date().getMonth()}${1}-${new Date().getDate()}`,
    supplier_invoice_number: from?.supplier_invoice_number,
    supplier_invoice_date: from?.supplier_invoice_date,
    user_id: localStorage.getItem("id"),
  });
  console.log(state);
  const [formsValue, setFormsvalue] = React.useState([
    {
      pod_type_id: 0,
      unit_count_id: 0,
      POD_Selection: 0,
      pod_quantity: 0,
      pod_price: 0,
      pod_vat: 0,
      pod_wht_id: 0,
      pod_crate: 0,
    },
  ]);

  const addFieldHandleChange = (i, e) => {
    const newFormValues = [...formsValue];
    newFormValues[i][e.target.name] = e.target.value;
    setFormsvalue(newFormValues);
  };
  const addFieldHandleChangeWname = (i, name, e) => {
    const newFormValues = [...formsValue];
    newFormValues[i][name] = e;
    setFormsvalue(newFormValues);
  };

  const addFormFields = () => {
    setFormsvalue([
      ...formsValue,
      {
        pod_type_id: 0,
        unit_count_id: 0,
        POD_Selection: 0,
        pod_quantity: 0,
        pod_price: 0,
        pod_vat: 0,
        pod_wht_id: 0,
        pod_crate: 0,
      },
    ]);
  };

  const removeFormFields = (i) => {
    const newFormValues = [...formsValue];
    newFormValues.splice(i, 1);
    setFormsvalue(newFormValues);
  };

  const { data: vendorList } = useQuery("getAllVendor");
  const { data: dropdownType } = useQuery("getDropdownType");
  const { data: produceList } = useQuery("getAllProduceItem");
  const { data: packagingList } = useQuery("getAllPackaging");
  const { data: BoxList } = useQuery("getAllBoxes");
  const { data: unitType } = useQuery("getAllUnit");
  useEffect(() => {
    if (!unitType?.length) return;
    getDetils();
  }, [unitType]);
  const handleChange = (event) => {
    const { name, value } = event.target;
    setState((prevState) => {
      return {
        ...prevState,
        [name]: value,
      };
    });
  };

  const updatePurchaseOrderDetils = (id) => {
    if (!from?.PO_ID) return;
    axios
      .post(`${API_BASE_URL}/updatePurchaseOrderDetails`, {
        po_id: id,
        data: details,
      })
      .then((response) => {
        // window.location.reload(navigate("/purchase_orders"));
        navigate("/purchase_orders");
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const addPurchaseOrderDetails = async (id) => {
    try {
      const response = await axios.post(
        `${API_BASE_URL}/addPurchaseOrderDetails`,
        {
          // po_id: id,
          // unit_count_id: pod_quantity,
          // data: formsValue.filter((v) => v.POD_Selection),
        }
      );
      console.log(response.data);
  
   
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const update = async (e) => {
    // if (buttonClicked) {
    //   return;
    // }
    setButtonClicked(true);
    try {
      const response = await axios.post(
        `${API_BASE_URL}/${"addPurchaseOrder"}`,
        state
      );
      console.log(response);
      setStock(response?.data);
      setFormsvalue([
        {
          pod_type_id: 0,
          unit_count_id: 0,
          POD_Selection: 0,
          pod_quantity: 0,
          pod_price: 0,
          pod_vat: 0,
          pod_wht_id: 0,
          pod_crate: 0,
        },
      ]);
      setState((prevState) => ({
        ...prevState, // Preserve previous data
        po_id: response.data?.po_id || from?.po_id || prevState.po_id,
        vendor_id: prevState.vendor_id, // Preserve other fields
        created: prevState.created,
        supplier_invoice_number: prevState.supplier_invoice_number,
        supplier_invoice_date: prevState.supplier_invoice_date,
        rounding: prevState.rounding,
      }));

      if (response.status === 200) {
        if (response.data.success) {
          // Close only the specific modal
          // const modalElement = document.getElementById("exampleModalCreate");
          // if (modalElement) {
          //     const modalInstance = bootstrap.Modal.getInstance(modalElement);
          //     if (modalInstance) {
          //         modalInstance.hide();

          //     }

          // }

          const id = response.data?.po_id || from?.po_id;
          setPodId(response?.data?.po_id);
          setModalOne(true);
          toast.success("Create Purchase Orders", {
            autoClose: 5000,
            theme: "colored",
          });
        } else {
          setShow(true);
        }
      }
    } catch (e) {
      console.log(e);

      toast.error("An error has occurred", {
        autoClose: 5000,
        theme: "colored",
      });
    }
  };
  // console.log(details);
  // console.log(formsValue);

  // js pratima
  const [podId, setPodId] = useState("");
  const [optionItem, setOptionItem] = useState([]);
  const [modalOne, setModalOne] = useState(false);
  const [unitItem, setUnitItem] = useState([]);

  const [formDataAdd, setFormDataAdd] = useState({
    quantity: "",
    crate: "",
    price: "",
    vat: "",
    wht: "",
    total: "",
  });
  const handleChangeAdd = (e) => {
    const { name, value } = e.target;
    setFormDataAdd((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleCloseModalOne = () => {
    setModalOne(false); // Hide the modal
  };

  const openModalOne = () => {
    setModalOne(true); // Show the modal
  };
  const handleChangeCreate = (event) => {
    const { name, value } = event.target;
    setState((prevState) => {
      return {
        ...prevState,
        [name]: value,
      };
    });
  };
  return (
    <>
      <Card
        title={`Purchase Order / ${from?.PO_ID ? "Update" : "Create"} Form`}
      >
        <div className="tab-content px-2 md:!px-4">
          <div className="tab-pane active" id="header" role="tabpanel">
            <div
              id="datatable_wrapper"
              className="information_dataTables dataTables_wrapper dt-bootstrap4"
            >
              <div className="formCreate">
                <form action="">
                  <div className="row cratePurchase">
                    <div className="col-lg-3 form-group parentFormPayment autoComplete">
                      <h6>Vendor</h6>
                      {/* <Autocomplete
                        options={
                          vendorList?.map((vendor) => ({
                            id: vendor.vendor_id,
                            name: vendor.name,
                          })) || []
                        } // Map vendorList to create options with `id` and `name`
                        getOptionLabel={(option) => option.name || ""} // Display the vendor name
                        value={
                          vendorList
                            ?.map((vendor) => ({
                              id: vendor.vendor_id,
                              name: vendor.name,
                            }))
                            .find((option) => option.id === state.vendor_id) ||
                          null
                        } // Match the current `vendor_id` in state with the options
                        onChange={(e, newValue) => {
                          setState({ ...state, vendor_id: newValue?.id || "" });
                          setState({
                            ...state,
                            vendor_name: newValue?.name || "",
                          });

                          // Update state with selected vendor's `id`
                        }}
                        isOptionEqualToValue={(option, value) =>
                          option.id === value.id
                        } // Ensure proper option matching
                        sx={{ width: 300 }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            placeholder="Select Vendor" // Adds a placeholder
                            InputLabelProps={{ shrink: false }} // Prevents floating label
                          />
                        )}
                      /> */}
                      <Autocomplete
                        options={
                          vendorList?.map((vendor) => ({
                            id: vendor.ID,
                            name: vendor.name,
                          })) || []
                        } // Map the vendor list to create options with `id` and `name`
                        getOptionLabel={(option) => option.name || ""} // Display the vendor name
                        value={
                          vendorList
                            ?.map((vendor) => ({
                              id: vendor.ID,
                              name: vendor.name,
                            }))
                            .find((option) => option.id === state.vendor_id) ||
                          null
                        } // Find the selected vendor by `vendor_id`
                        onChange={(e, newValue) => {
                          setState({
                            ...state,
                            vendor_id: newValue?.id || "",
                            vendor_name: newValue?.name || "",
                          }); // Update `state.vendor_id` with the selected option's `id`
                        }}
                        sx={{ width: 300 }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            placeholder="Select Vendor" // Adds a placeholder
                            InputLabelProps={{ shrink: false }} // Prevents floating label
                          />
                        )}
                      />
                    </div>
                    <div className="col-lg-3 form-group">
                      <h6>PO Date</h6>
                      <input
                        type="date"
                        name="created"
                        value={state.created}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="col-lg-3 form-group">
                      <h6>Invoice Number</h6>
                      <input
                        className="w-full"
                        type="text"
                        name="supplier_invoice_number"
                        onChange={handleChange}
                        value={state.supplier_invoice_number}
                      />
                    </div>
                    <div className="col-lg-3 form-group">
                      <h6>Invoice Date</h6>
                      <input
                        type="date"
                        name="supplier_invoice_date"
                        value={state.supplier_invoice_date}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="col-lg-3 form-group">
                      <h6>Rounding</h6>
                      <input
                        type="number"
                        name="rounding"
                        value={state.rounding}
                        onChange={handleChangeCreate}
                      />
                    </div>
                  </div>
                  <div className="addButton">
                    {/* Button trigger modal */}
                    <button
                      type="button"
                      className="btn btn-primary"
                      // onClick={openModalOne}
                      onClick={update}
                    >
                      Add
                    </button>
                    {modalOne && (
                      <div
                        className="fixed inset-0 flex items-center justify-center"
                        style={{ zIndex: "9999" }}
                      >
                        <div
                          className="fixed w-screen h-screen bg-black/20"
                          onClick={handleCloseModalOne}
                        />
                        <div className="bg-white rounded-lg shadow-lg max-w-md w-full ">
                          <div className="crossArea">
                            <h3>Edit Details</h3>
                            <p onClick={handleCloseModalOne}>
                              <CloseIcon />
                            </p>
                          </div>
                          <div className="formEan formCreate">
                            <div className="modal-body modalShipTo p-0 ">
                              {/* <h1>hello</h1> */}

                              <div className="addMOdalContent formCreate mt-0 px-2">
                                <div className="col-lg-12 autoComplete mb-2 ">
                                  <h6>Select Item</h6>
                                  <Autocomplete
                                    disablePortal
                                    options={
                                      Array.isArray(optionItem)
                                        ? optionItem
                                        : []
                                    }
                                    getOptionLabel={(option) =>
                                      option.Name_EN || option.Name_TH || ""
                                    }
                                    sx={{ width: 300 }}
                                    renderInput={(params) => (
                                      <TextField
                                        {...params}
                                        placeholder="Select Item"
                                      />
                                    )}
                                  />
                                </div>
                                <div className="col-lg-12 autoComplete mb-2">
                                  <h6>Unit</h6>
                                  <Autocomplete
                                    disablePortal
                                    options={
                                      Array.isArray(unitItem) ? unitItem : []
                                    }
                                    getOptionLabel={(option) =>
                                      option.Name_EN ||
                                      option.Name_TH ||
                                      "Unknown Unit"
                                    }
                                    sx={{ width: 300 }}
                                    renderInput={(params) => (
                                      <TextField
                                        {...params}
                                        placeholder="Unit"
                                      />
                                    )}
                                  />
                                </div>
                                <div className="col-lg-12 mb-2">
                                  <h6>Quantity</h6>
                                  <input
                                    className="mb-0"
                                    type="text"
                                    name="quantity"
                                    value={formDataAdd.quantity || ""}
                                    placeholder="Quantity"
                                    onChange={handleChangeAdd}
                                  />
                                </div>
                                <div className="col-lg-12 mb-2">
                                  <h6>Crate</h6>
                                  <input
                                    className="mb-0"
                                    type="number"
                                    name="crate"
                                    value={formDataAdd.crate}
                                    placeholder="Crate"
                                    onChange={handleChangeAdd}
                                  />
                                </div>

                                <div className="col-lg-12 mb-2">
                                  <h6>Price</h6>
                                  <input
                                    className="mb-0"
                                    type="number"
                                    name="price"
                                    value={formDataAdd.price}
                                    placeholder="Price"
                                    onChange={handleChangeAdd}
                                  />
                                </div>

                                <div className="row mb-2">
                                  <div className="col-lg-6">
                                    <h6>VAT</h6>
                                    <input
                                      className="mb-0"
                                      type="number"
                                      name="vat"
                                      value={formDataAdd.vat}
                                      placeholder="VAT"
                                      onChange={handleChangeAdd}
                                    />
                                  </div>

                                  <div className="col-lg-6">
                                    <h6>WHT</h6>
                                    <input
                                      className="mb-0"
                                      type="number"
                                      name="wht"
                                      value={formDataAdd.wht}
                                      placeholder="WHT"
                                      onChange={handleChangeAdd}
                                    />
                                  </div>
                                </div>

                                <div className="row">
                                  <div className="col-lg-12 mb-2">
                                    <h6>Total</h6>
                                    <input
                                      className="mb-0"
                                      type="number"
                                      name="total"
                                      value={formDataAdd.total}
                                      placeholder="Total"
                                      onChange={handleChangeAdd}
                                    />
                                  </div>
                                </div>

                                <button
                                  type="button"
                                  className="UpdatePopupBtn btn btn-primary m-0"
                                  onClick={addPurchaseOrderDetails}
                                >
                                  Add
                                </button>
                              </div>
                            </div>
                          </div>
                          <div className="modal-footer"></div>
                        </div>
                      </div>
                    )}
                  </div>
                  {/* table new */}

                  <div
                    id="datatable_wrapper"
                    className="information_dataTables dataTables_wrapper dt-bootstrap4 table-responsive mt-"
                  >
                    <table
                      id="example"
                      className="display transPortCreate table table-hover table-striped borderTerpProduce table-responsive purchaseCreateTable"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          <th style={{ width: "170px" }}>Pod Code</th>
                          {/* <th style={{ width: "250px" }}>Type</th> */}
                          <th style={{ width: "350px" }}>Item</th>
                          <th style={{ width: "150px" }}>Quantity</th>
                          <th style={{ width: "100px" }}>Unit</th>
                          <th style={{ width: "150px" }}>Price</th>
                          <th style={{ width: "70px" }}>VAT</th>
                          <th style={{ width: "150px" }}>Total</th>
                          <th style={{ width: "100px" }}>WHT</th>
                          <th style={{ width: "100px" }}>Crate</th>
                          <th style={{ width: "100px" }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>PO-20250307001 </td>
                          <td>Produce</td>
                          <td>0 </td>
                          <td>0 </td>
                          <td>0 </td>
                          <td>0</td>
                          <td>0</td>
                          <td>0</td>
                          <td>0</td>
                          <td>
                            <button type="button">
                              <i className="mdi mdi-pencil text-2xl" />
                            </button>
                            <button type="button">
                              <i className="mdi mdi-minus text-2xl" />
                            </button>
                          </td>
                        </tr>
                        <tr>
                          <td>PO-20250307001 </td>
                          <td>Produce</td>
                          <td>0 </td>
                          <td>0 </td>
                          <td>0 </td>
                          <td>0</td>
                          <td>0</td>
                          <td>0</td>
                          <td>0</td>
                          <td>
                            <button type="button">
                              <i className="mdi mdi-pencil text-2xl" />
                            </button>
                            <button type="button">
                              <i className="mdi mdi-minus text-2xl" />
                            </button>
                          </td>
                        </tr>
                      </tbody>
                      {/* <tbody>
                              {details?.map((v, i) => (
                                <tr key={`b_${i}`} className="rowCursorPointer">
                                  <td className="borderUnsetPod">
                                    {v.pod_status == "1" ? (
                                      <input
                                        className="border-0"
                                        value={v.pod_code}
                                      />
                                    ) : (
                                      <>{v.pod_code}</>
                                    )}
                                  </td>

                                  <td className="autoFull">
                                    {v.pod_status == "1" ? (
                                      <Autocomplete
                                        className="unsetPurchaseWidth"
                                        value={
                                          dropdownItems?.find(
                                            (item) => item.ID === v.dropDown_id
                                          ) || null
                                        }
                                        options={dropdownItems}
                                        getOptionLabel={(option) =>
                                          option.produce_name_en || ""
                                        }
                                        onChange={(event, newValue) => {
                                          if (+v.pod_status !== 1) return;
                                          const newEditPackaging = [...details];
                                          newEditPackaging[i].dropDown_id =
                                            newValue?.ID || null;
                                          setDetails(newEditPackaging);
                                        }}
                                        renderInput={(params) => (
                                          <TextField
                                            {...params}
                                            variant="outlined"
                                            placeholder="Select Item"
                                            // label="Select Produce"
                                          />
                                        )}
                                      />
                                    ) : (
                                      <> {v.produce_name_en} </>
                                    )}
                                  </td>

                                  <td clas>
                                    {v.pod_status == "1" ? (
                                      <input
                                        className="border-0"
                                        type="text"
                                        name="pod_quantity"
                                        disabled={+v.pod_status != 1}
                                        value={v.pod_quantity}
                                        onChange={(e) => handleEditDatils(i, e)}
                                      />
                                    ) : (
                                      <> {v.pod_quantity}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <Autocomplete
                                        options={unitType}
                                        value={
                                          unitType?.find(
                                            (item) =>
                                              item.unit_id === v.unit_count_id
                                          ) || null
                                        }
                                        getOptionLabel={(option) =>
                                          option.unit_name_en || ""
                                        }
                                        onChange={(event, newValue) => {
                                          if (+v.pod_status !== 1) return;
                                          const newEditPackaging = [...details];
                                          newEditPackaging[i].unit_count_id =
                                            newValue?.unit_id || null;
                                          setDetails(newEditPackaging);
                                        }}
                                        renderInput={(params) => (
                                          <TextField
                                            {...params}
                                            variant="outlined"
                                            placeholder="Select Unit"
                                            // label="Select Unit"
                                          />
                                        )}
                                      />
                                    ) : (
                                      // <ComboBox
                                      //   options={unitType?.map((v) => ({
                                      //     id: v.unit_id,
                                      //     name: v.unit_name_en,
                                      //   }))}
                                      //   value={v.unit_count_id}
                                      //   onChange={(e) => {
                                      //     if (+v.pod_status != 1) return;
                                      //     const newEditPackaging = [...details];
                                      //     newEditPackaging[i].unit_count_id = e;
                                      //     setDetails(newEditPackaging);
                                      //   }}
                                      // />
                                      <> {v.unit_count_id}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="number"
                                        name="pod_price"
                                        className="border-0"
                                        defaultValue={v.pod_price}
                                        disabled={+v.pod_status != 1}
                                        onChange={(e) => handleEditDatils(i, e)}
                                      />
                                    ) : (
                                      <> {v.pod_price}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="number"
                                        name="pod_vat"
                                        className="border-0"
                                        defaultValue={v.pod_vat}
                                        disabled={+v.pod_status != 1}
                                        onChange={(e) => handleEditDatils(i, e)}
                                        style={{ width: "50px" }}
                                      />
                                    ) : (
                                      <> {v.pod_vat}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="text"
                                        readOnly
                                        className="border-0"
                                        disabled={+v.pod_status != 1}
                                        value={(
                                          +(
                                            +v.pod_price *
                                            +v.pod_quantity *
                                            (v.pod_vat / 100)
                                          ) +
                                          +v.pod_price * +v.pod_quantity
                                        ).toLocaleString("en-us")}
                                      />
                                    ) : (
                                      <>
                                        {" "}
                                        {(
                                          +(
                                            +v.pod_price *
                                            +v.pod_quantity *
                                            (v.pod_vat / 100)
                                          ) +
                                          +v.pod_price * +v.pod_quantity
                                        ).toLocaleString("en-us")}
                                      </>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="text"
                                        name="pod_wht_id"
                                        className="border-0"
                                        disabled={+v.pod_status != 1}
                                        style={{ width: "50px" }}
                                        value={v.pod_wht_id}
                                        onChange={(e) => handleEditDatils(i, e)}
                                      />
                                    ) : (
                                      <> {v.pod_wht_id}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="text"
                                        name="pod_crate"
                                        className="border-0"
                                        style={{ width: "70px" }}
                                        disabled={+v.pod_status != 1}
                                        value={v.pod_crate}
                                        onChange={(e) => handleEditDatils(i, e)}
                                      />
                                    ) : (
                                      <> {v.pod_crate}</>
                                    )}
                                  </td>
                                  <td className="editIcon">
                                    {+v.pod_status == 1 ? (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const i = window.confirm(
                                            "Do you want to delete this Order details?"
                                          );
                                          if (i) {
                                            deleteDetails(v.pod_id);
                                          }
                                        }}
                                      >
                                        <i className="mdi mdi-trash-can-outline" />
                                      </button>
                                    ) : (
                                      <> </>
                                    )}
                                  </td>
                                </tr>
                              ))}
                              {formsValue?.map((element, index) => (
                                <tr
                                  key={`a_${index}`}
                                  className="rowCursorPointer"
                                >
                                  <td> </td>
                                  <td>
                                    <Autocomplete
                                      value={
                                        dropdownItems?.find(
                                          (item) =>
                                            item.ID === element.POD_Selection
                                        ) || null
                                      }
                                      options={dropdownItems}
                                      getOptionLabel={(option) =>
                                        option.Name_EN || ""
                                      }
                                      onChange={(event, newValue) =>
                                        addFieldHandleChangeWname(
                                          index,
                                          "POD_Selection",
                                          newValue?.ID || null
                                        )
                                      }
                                      renderInput={(params) => (
                                        <TextField
                                          {...params}
                                          placeholder="Select Item"
                                          variant="outlined"
                                          // label="Select POD"
                                        />
                                      )}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name="pod_quantity"
                                      className="border-0"
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_quantity}
                                    />
                                  </td>
                                  <td>
                                    <Autocomplete
                                      value={
                                        unitType?.find(
                                          (item) =>
                                            item.ID === element.unit_count_id
                                        ) || null
                                      }
                                      options={unitType}
                                      getOptionLabel={(option) =>
                                        option.Name_EN || ""
                                      }
                                      onChange={(event, newValue) =>
                                        addFieldHandleChangeWname(
                                          index,
                                          "unit_count_id",
                                          newValue?.ID || null
                                        )
                                      }
                                      renderInput={(params) => (
                                        <TextField
                                          {...params}
                                          variant="outlined"
                                          placeholder="Select Unit"
                                        />
                                      )}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="number"
                                      name="pod_price"
                                      className="border-0"
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_price}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="number"
                                      name="pod_vat"
                                      className="border-0"
                                      style={{ width: "50px" }}
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_vat}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      readOnly
                                      className="border-0"
                                      value={(
                                        +(
                                          +element.pod_price *
                                          +element.pod_quantity *
                                          (element.pod_vat / 100)
                                        ) +
                                        +element.pod_price *
                                          +element.pod_quantity
                                      ).toLocaleString("en-us")}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name="pod_wht_id"
                                      style={{ width: "50px" }}
                                      className="border-0"
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_wht_id}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name="pod_crate"
                                      className="border-0"
                                      style={{ width: "70px" }}
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_crate}
                                    />
                                  </td>
                                  <td>
                                    {index == formsValue.length - 1 ? (
                                      <button
                                        type="button"
                                        onClick={addFormFields}
                                        className="cursor-pointer"
                                      >
                                        <i className="mdi mdi-plus text-xl" />
                                      </button>
                                    ) : (
                                      <button
                                        type="button"
                                        className="cursor-pointer"
                                        onClick={() => removeFormFields(index)}
                                      >
                                        <i className="mdi mdi-trash-can-outline text-xl" />
                                      </button>
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody> */}
                    </table>
                  </div>
                  {/* table new end */}
                  {/* <div
                    id="datatable_wrapper"
                    className="information_dataTables dataTables_wrapper dt-bootstrap4 table-responsive mt-"
                  >
                    <table
                      id="example"
                      className="display transPortCreate table table-hover table-striped borderTerpProduce table-responsive purchaseCreateTable"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          <th style={{ width: "170px" }}>Pod Code</th>
                         
                          <th style={{ width: "350px" }}>Item</th>
                          <th style={{ width: "150px" }}>Quantity</th>
                          <th style={{ width: "100px" }}>Unit</th>
                          <th style={{ width: "150px" }}>Price</th>
                          <th style={{ width: "70px" }}>VAT</th>
                          <th style={{ width: "150px" }}>Total</th>
                          <th style={{ width: "100px" }}>WHT</th>
                          <th style={{ width: "100px" }}>Crate</th>
                          <th style={{ width: "100px" }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {details?.map((v, i) => (
                          <tr key={`b_${i}`} className="rowCursorPointer">
                            <td className="borderUnsetPod">
                              {v.pod_status == "1" ? (
                                <input
                                  className="border-0"
                                  value={v.pod_code}
                                />
                              ) : (
                                <>{v.pod_code}</>
                              )}
                            </td>

                            <td>
                              {v.pod_status == "1" ? (
                                <Autocomplete
                                  className="unsetPurchaseWidth"
                                  value={
                                    dropdownItems?.find(
                                      (item) => item.ID === v.dropDown_id
                                    ) || null
                                  }
                                  options={dropdownItems}
                                  getOptionLabel={(option) =>
                                    option.Name_EN || ""
                                  }
                                  onChange={(event, newValue) => {
                                    if (+v.pod_status !== 1) return;
                                    const newEditPackaging = [...details];
                                    newEditPackaging[i].dropDown_id =
                                      newValue?.ID || null;
                                    setDetails(newEditPackaging);
                                  }}
                                  renderInput={(params) => (
                                    <TextField
                                      {...params}
                                      variant="outlined"
                                      placeholder="Select Item"
                                  
                                    />
                                  )}
                                />
                              ) : (
                                <> {v.produce_name_en} </>
                              )}
                            </td>

                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  className="border-0"
                                  type="text"
                                  name="pod_quantity"
                                  disabled={+v.pod_status != 1}
                                  value={v.pod_quantity}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_quantity}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <Autocomplete
                                  options={unitType}
                                  value={
                                    unitType?.find(
                                      (item) => item.ID === v.unit_count_id
                                    ) || null
                                  }
                                  getOptionLabel={(option) =>
                                    option.Name_EN || ""
                                  }
                                  onChange={(event, newValue) => {
                                    if (+v.pod_status !== 1) return;
                                    const newEditPackaging = [...details];
                                    newEditPackaging[i].unit_count_id =
                                      newValue?.ID || null;
                                    setDetails(newEditPackaging);
                                  }}
                                  renderInput={(params) => (
                                    <TextField
                                      {...params}
                                      variant="outlined"
                                      placeholder="Select Unit"
                                    
                                    />
                                  )}
                                />
                              ) : (
                                <> {v.unit_count_id}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="number"
                                  name="pod_price"
                                  className="border-0"
                                  defaultValue={v.pod_price}
                                  disabled={+v.pod_status != 1}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_price}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="number"
                                  name="pod_vat"
                                  className="border-0"
                                  defaultValue={v.pod_vat}
                                  disabled={+v.pod_status != 1}
                                  onChange={(e) => handleEditDatils(i, e)}
                                  style={{ width: "50px" }}
                                />
                              ) : (
                                <> {v.pod_vat}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  readOnly
                                  className="border-0"
                                  disabled={+v.pod_status != 1}
                                  value={(
                                    +(
                                      +v.pod_price *
                                      +v.pod_quantity *
                                      (v.pod_vat / 100)
                                    ) +
                                    +v.pod_price * +v.pod_quantity
                                  ).toLocaleString("en-us")}
                                />
                              ) : (
                                <>
                                  {" "}
                                  {(
                                    +(
                                      +v.pod_price *
                                      +v.pod_quantity *
                                      (v.pod_vat / 100)
                                    ) +
                                    +v.pod_price * +v.pod_quantity
                                  ).toLocaleString("en-us")}
                                </>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  name="pod_wht_id"
                                  className="border-0"
                                  disabled={+v.pod_status != 1}
                                  style={{ width: "50px" }}
                                  value={v.pod_wht_id}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_wht_id}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  name="pod_crate"
                                  className="border-0"
                                  style={{ width: "70px" }}
                                  disabled={+v.pod_status != 1}
                                  value={v.pod_crate}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_crate}</>
                              )}
                            </td>
                            <td className="editIcon">
                              {+v.pod_status == 1 ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const i = window.confirm(
                                      "Do you want to delete this Order details?"
                                    );
                                    if (i) {
                                      deleteDetails(v.pod_id);
                                    }
                                  }}
                                >
                                  <i className="mdi mdi-trash-can-outline" />
                                </button>
                              ) : (
                                <> </>
                              )}
                            </td>
                          </tr>
                        ))}
                        {formsValue?.map((element, index) => (
                          <tr
                            key={`a_${index}`}
                            className="rowCursorPointer"
                            data-bs-toggle="modal"
                            data-bs-target="#myModal"
                          >
                            <td> </td>

                            <td>
                              <Autocomplete
                                value={
                                  dropdownItems?.find(
                                    (item) => item.ID === element.POD_Selection
                                  ) || null
                                }
                                options={dropdownItems}
                                getOptionLabel={(option) =>
                                  option.Name_EN || ""
                                }
                                onChange={(event, newValue) =>
                                  addFieldHandleChangeWname(
                                    index,
                                    "POD_Selection",
                                    newValue?.ID || null
                                  )
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    placeholder="Select Item"
                                    variant="outlined"
                                  
                                  />
                                )}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_quantity"
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_quantity}
                              />
                            </td>
                            <td>
                              <Autocomplete
                                value={
                                  unitType?.find(
                                    (item) => item.ID === element.unit_count_id
                                  ) || null
                                }
                                options={unitType}
                                getOptionLabel={(option) =>
                                  option.Name_EN || ""
                                }
                                onChange={(event, newValue) =>
                                  addFieldHandleChangeWname(
                                    index,
                                    "unit_count_id",
                                    newValue?.ID || null
                                  )
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    variant="outlined"
                                    placeholder="Select Unit"
                                  />
                                )}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                name="pod_price"
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_price}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                name="pod_vat"
                                className="border-0"
                                style={{ width: "50px" }}
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_vat}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                readOnly
                                className="border-0"
                                value={(
                                  +(
                                    +element.pod_price *
                                    +element.pod_quantity *
                                    (element.pod_vat / 100)
                                  ) +
                                  +element.pod_price * +element.pod_quantity
                                ).toLocaleString("en-us")}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_wht_id"
                                style={{ width: "50px" }}
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_wht_id}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_crate"
                                className="border-0"
                                style={{ width: "70px" }}
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_crate}
                              />
                            </td>
                            <td>
                              {index == formsValue.length - 1 ? (
                                <button
                                  type="button"
                                  onClick={addFormFields}
                                  className="cursor-pointer"
                                >
                                  <i className="mdi mdi-plus text-xl" />
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  className="cursor-pointer"
                                  onClick={() => removeFormFields(index)}
                                >
                                  <i className="mdi mdi-trash-can-outline text-xl" />
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div> */}
                </form>
              </div>
            </div>
          </div>
          <div className="card-footer">
            <button
              className="btn btn-primary"
              type="submit"
              name="signup"
              onClick={update}
              disabled={buttonClicked}
            >
              {from?.PO_ID ? "Update" : "Create"}
            </button>
            <Link className="btn btn-danger" to={"/purchase_orders"}>
              Cancel
            </Link>
          </div>
        </div>
      </Card>

      <Modal
        className="modalError receiveModal"
        show={show}
        onHide={handleClose}
      >
        <div className="modal-content">
          <div
            className="modal-header border-0"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          >
            <h1 className="modal-title fs-5" id="exampleModalLabel">
              Purchase Order Check
            </h1>
            <button
              style={{ color: "#fff", fontSize: "30px" }}
              type="button"
              // onClick={() => setShow(false)}
              onClick={closeIcon}
            >
              <i class="mdi mdi-close"></i>
            </button>
          </div>
          <div
            className="modal-body"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          >
            <div className="eanCheck errorMessage recheckReceive">
              <p style={{ backgroundColor: color ? "" : "#631f37" }}>
                {stock.message_en ? stock.message_en : "NULL"}
              </p>
              <p style={{ backgroundColor: color ? "" : "#631f37" }}>
                {stock.message_th ? stock.message_th : "NULL"}
              </p>
              <div className="closeBtnRece">
                <button onClick={closeIcon}>Close</button>
              </div>
            </div>
          </div>
          <div
            className="modal-footer"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          ></div>
        </div>
      </Modal>
    </>
  );
};

export default CreatePurchaseOrder;
