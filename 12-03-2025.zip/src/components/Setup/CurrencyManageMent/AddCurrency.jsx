const AddCurrency = () => {
	return <div>AddCurrency</div>
}

export default AddCurrency
