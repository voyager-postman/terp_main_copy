import axios from "axios";
import React, { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { ComboBox } from "../combobox";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import { Button, Modal } from "react-bootstrap";
const CreatePurchaseOrder = () => {
  const [buttonClicked, setButtonClicked] = React.useState(false);
  const location = useLocation();
  const [dropdownItems, setDropdownItems] = useState([]);
  const { from } = location.state || {};
  console.log(from);
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [stock, setStock] = useState("");
  const [color, setColor] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [details, setDetails] = React.useState([]);
  const getDetils = () => {
    if (from?.po_id) {
      axios
        .get(`${API_BASE_URL}/getPurchaseOrderDetails?po_id=${from?.po_id}`)
        .then((response) => {
          console.log(response);
          setDetails(response.data.data);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };
  const closeIcon = () => {
    setShow(false);
    navigate("/purchase_orders");
  };
  const handleEditDatils = (i, e) => {
    const newEditPackaging = [...details];
    newEditPackaging[i][e.target.name] = e.target.value;
    setDetails(newEditPackaging);
  };
  const itemData1 = async () => {
    try {
      const response = await axios.post(
        `${API_BASE_URL}/PurchaseTypeItemsList`
      );
      setDropdownItems(response.data.data || []);
    } catch (error) {
      console.error("Error fetching purchase type items:", error);
    }
  };
  useEffect(() => {
    itemData1();
  }, []);
  const deleteDetails = async (pod_id) => {
    try {
      await axios.post(`${API_BASE_URL}/deletePurchaseOrderDetails`, {
        pod_id: pod_id,
      });
      toast.success("Deleted Successfully", {
        autoClose: 1000,
        theme: "colored",
      });
      getDetils();
    } catch (e) {}
  };

  const [state, setState] = React.useState({
    po_id: from?.po_id,
    vendor_id: from?.vendor_id,
    created: from?.created || "0000-00-00",
    // `${new Date().getFullYear()}-${new Date().getMonth()}${1}-${new Date().getDate()}`,
    supplier_invoice_number: from?.supplier_invoice_number,
    supplier_invoice_date: from?.supplier_invoice_date,
    user_id: localStorage.getItem("id"),
  });
  const [formsValue, setFormsvalue] = React.useState([
    {
      pod_type_id: 0,
      unit_count_id: 0,
      POD_Selection: 0,
      pod_quantity: 0,
      pod_price: 0,
      pod_vat: 0,
      pod_wht_id: 0,
      pod_crate: 0,
    },
  ]);

  const addFieldHandleChange = (i, e) => {
    const newFormValues = [...formsValue];
    newFormValues[i][e.target.name] = e.target.value;
    setFormsvalue(newFormValues);
  };
  const addFieldHandleChangeWname = (i, name, e) => {
    const newFormValues = [...formsValue];
    newFormValues[i][name] = e;
    setFormsvalue(newFormValues);
  };

  const addFormFields = () => {
    setFormsvalue([
      ...formsValue,
      {
        pod_type_id: 0,
        unit_count_id: 0,
        POD_Selection: 0,
        pod_quantity: 0,
        pod_price: 0,
        pod_vat: 0,
        pod_wht_id: 0,
        pod_crate: 0,
      },
    ]);
  };

  const removeFormFields = (i) => {
    const newFormValues = [...formsValue];
    newFormValues.splice(i, 1);
    setFormsvalue(newFormValues);
  };

  const { data: vendorList } = useQuery("getAllVendor");
  const { data: dropdownType } = useQuery("getDropdownType");
  const { data: produceList } = useQuery("getAllProduceItem");
  const { data: packagingList } = useQuery("getAllPackaging");
  const { data: BoxList } = useQuery("getAllBoxes");
  const { data: unitType } = useQuery("getAllUnit");
  useEffect(() => {
    if (!unitType?.length) return;
    getDetils();
  }, [unitType]);
  const handleChange = (event) => {
    const { name, value } = event.target;
    setState((prevState) => {
      return {
        ...prevState,
        [name]: value,
      };
    });
  };

  const updatePurchaseOrderDetils = (id) => {
    if (!from?.po_id) return;
    axios
      .post(`${API_BASE_URL}/updatePurchaseOrderDetails`, {
        po_id: id,
        data: details,
      })
      .then((response) => {
        // window.location.reload(navigate("/purchase_orders"));
        navigate("/purchase_orders");
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const addPurchaseOrderDetails = (id) => {
    axios
      .post(`${API_BASE_URL}/addPurchaseOrderDetails`, {
        po_id: id,
        data: formsValue.filter((v) => v.POD_Selection),
      })
      .then((response) => {})
      .catch((error) => {
        console.log(error);
      });
  };
  const update = async () => {
    if (buttonClicked) {
      return;
    }
    setButtonClicked(true);
    try {
      const response = await axios.post(
        `${API_BASE_URL}/${
          from?.po_id ? "updatePurchaseOrder" : "addPurchaseOrder"
        }`,
        state
      );
      console.log(response);
      setStock(response?.data);
      if (response.data.success) {
        const id = response.data?.po_id || from?.po_id;
        if (id) {
          addPurchaseOrderDetails(id);
          updatePurchaseOrderDetils(id);
        }
        toast.success("Updated Purchase Orders", {
          autoClose: 5000,
          theme: "colored",
        });
      } else {
        setShow(true);
      }

      // window.location.reload(); // Refresh the page after navigation
    } catch (e) {
      setButtonClicked(false);
      toast.error("Error has occured", {
        autoClose: 5000,
        theme: "colored",
      });
    }
  };
  console.log(details);

  return (
    <>
      <Card
        title={`Purchase Order / ${from?.po_id ? "Update" : "Create"} Form`}
      >
        <div className="tab-content px-2 md:!px-4">
          <div className="tab-pane active" id="header" role="tabpanel">
            <div
              id="datatable_wrapper"
              className="information_dataTables dataTables_wrapper dt-bootstrap4"
            >
              <div className="formCreate">
                <form action="">
                  <div className="row cratePurchase">
                    <div className="col-lg-3 form-group parentFormPayment autoComplete">
                      <h6>Vendor</h6>
                      <Autocomplete
                        options={
                          vendorList?.map((vendor) => ({
                            id: vendor.vendor_id,
                            name: vendor.name,
                          })) || []
                        } // Map vendorList to create options with `id` and `name`
                        getOptionLabel={(option) => option.name || ""} // Display the vendor name
                        value={
                          vendorList
                            ?.map((vendor) => ({
                              id: vendor.vendor_id,
                              name: vendor.name,
                            }))
                            .find((option) => option.id === state.vendor_id) ||
                          null
                        } // Match the current `vendor_id` in state with the options
                        onChange={(e, newValue) => {
                          setState({ ...state, vendor_id: newValue?.id || "" }); // Update state with selected vendor's `id`
                        }}
                        isOptionEqualToValue={(option, value) =>
                          option.id === value.id
                        } // Ensure proper option matching
                        sx={{ width: 300 }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            placeholder="Select Vendor" // Adds a placeholder
                            InputLabelProps={{ shrink: false }} // Prevents floating label
                          />
                        )}
                      />
                    </div>
                    <div className="col-lg-3 form-group">
                      <h6>PO Date</h6>
                      <input
                        type="date"
                        name="created"
                        value={state.created}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="col-lg-3 form-group">
                      <h6>Invoice Number</h6>
                      <input
                        className="w-full"
                        type="text"
                        name="supplier_invoice_number"
                        onChange={handleChange}
                        value={state.supplier_invoice_number}
                      />
                    </div>
                    <div className="col-lg-3 form-group">
                      <h6>Invoice Date</h6>
                      <input
                        type="date"
                        name="supplier_invoice_date"
                        value={state.supplier_invoice_date}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  <div
                    id="datatable_wrapper"
                    className="information_dataTables dataTables_wrapper dt-bootstrap4 table-responsive mt-"
                  >
                    <table
                      id="example"
                      className="display transPortCreate table table-hover table-striped borderTerpProduce table-responsive purchaseCreateTable"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          <th style={{ width: "170px" }}>Pod Code</th>
                          {/* <th style={{ width: "250px" }}>Type</th> */}
                          <th style={{ width: "350px" }}>Item</th>
                          <th style={{ width: "150px" }}>Quantity</th>
                          <th style={{ width: "100px" }}>Unit</th>
                          <th style={{ width: "150px" }}>Price</th>
                          <th style={{ width: "70px" }}>VAT</th>
                          <th style={{ width: "150px" }}>Total</th>
                          <th style={{ width: "100px" }}>WHT</th>
                          <th style={{ width: "100px" }}>Crate</th>
                          <th style={{ width: "100px" }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {details?.map((v, i) => (
                          <tr key={`b_${i}`} className="rowCursorPointer">
                            <td className="borderUnsetPod">
                              {v.pod_status == "1" ? (
                                <input
                                  className="border-0"
                                  value={v.pod_code}
                                />
                              ) : (
                                <>{v.pod_code}</>
                              )}
                            </td>

                            <td>
                              {v.pod_status == "1" ? (
                                <Autocomplete
                                  className="unsetPurchaseWidth"
                                  value={
                                    dropdownItems?.find(
                                      (item) => item.ID === v.dropDown_id
                                    ) || null
                                  }
                                  options={dropdownItems}
                                  getOptionLabel={(option) =>
                                    option.produce_name_en || ""
                                  }
                                  onChange={(event, newValue) => {
                                    if (+v.pod_status !== 1) return;
                                    const newEditPackaging = [...details];
                                    newEditPackaging[i].dropDown_id =
                                      newValue?.ID || null;
                                    setDetails(newEditPackaging);
                                  }}
                                  renderInput={(params) => (
                                    <TextField
                                      {...params}
                                      variant="outlined"
                                      placeholder="Select Item"
                                      // label="Select Produce"
                                    />
                                  )}
                                />
                              ) : (
                                <> {v.produce_name_en} </>
                              )}
                            </td>

                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  className="border-0"
                                  type="text"
                                  name="pod_quantity"
                                  disabled={+v.pod_status != 1}
                                  value={v.pod_quantity}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_quantity}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <Autocomplete
                                  options={unitType}
                                  value={
                                    unitType?.find(
                                      (item) => item.unit_id === v.unit_count_id
                                    ) || null
                                  }
                                  getOptionLabel={(option) =>
                                    option.unit_name_en || ""
                                  }
                                  onChange={(event, newValue) => {
                                    if (+v.pod_status !== 1) return;
                                    const newEditPackaging = [...details];
                                    newEditPackaging[i].unit_count_id =
                                      newValue?.unit_id || null;
                                    setDetails(newEditPackaging);
                                  }}
                                  renderInput={(params) => (
                                    <TextField
                                      {...params}
                                      variant="outlined"
                                      placeholder="Select Unit"
                                      // label="Select Unit"
                                    />
                                  )}
                                />
                              ) : (
                                // <ComboBox
                                //   options={unitType?.map((v) => ({
                                //     id: v.unit_id,
                                //     name: v.unit_name_en,
                                //   }))}
                                //   value={v.unit_count_id}
                                //   onChange={(e) => {
                                //     if (+v.pod_status != 1) return;
                                //     const newEditPackaging = [...details];
                                //     newEditPackaging[i].unit_count_id = e;
                                //     setDetails(newEditPackaging);
                                //   }}
                                // />
                                <> {v.unit_count_id}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="number"
                                  name="pod_price"
                                  className="border-0"
                                  defaultValue={v.pod_price}
                                  disabled={+v.pod_status != 1}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_price}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="number"
                                  name="pod_vat"
                                  className="border-0"
                                  defaultValue={v.pod_vat}
                                  disabled={+v.pod_status != 1}
                                  onChange={(e) => handleEditDatils(i, e)}
                                  style={{ width: "50px" }}
                                />
                              ) : (
                                <> {v.pod_vat}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  readOnly
                                  className="border-0"
                                  disabled={+v.pod_status != 1}
                                  value={(
                                    +(
                                      +v.pod_price *
                                      +v.pod_quantity *
                                      (v.pod_vat / 100)
                                    ) +
                                    +v.pod_price * +v.pod_quantity
                                  ).toLocaleString("en-us")}
                                />
                              ) : (
                                <>
                                  {" "}
                                  {(
                                    +(
                                      +v.pod_price *
                                      +v.pod_quantity *
                                      (v.pod_vat / 100)
                                    ) +
                                    +v.pod_price * +v.pod_quantity
                                  ).toLocaleString("en-us")}
                                </>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  name="pod_wht_id"
                                  className="border-0"
                                  disabled={+v.pod_status != 1}
                                  style={{ width: "50px" }}
                                  value={v.pod_wht_id}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_wht_id}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  name="pod_crate"
                                  className="border-0"
                                  style={{ width: "70px" }}
                                  disabled={+v.pod_status != 1}
                                  value={v.pod_crate}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_crate}</>
                              )}
                            </td>
                            <td className="editIcon">
                              {+v.pod_status == 1 ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const i = window.confirm(
                                      "Do you want to delete this Order details?"
                                    );
                                    if (i) {
                                      deleteDetails(v.pod_id);
                                    }
                                  }}
                                >
                                  <i className="mdi mdi-trash-can-outline" />
                                </button>
                              ) : (
                                <> </>
                              )}
                            </td>
                          </tr>
                        ))}
                        {formsValue?.map((element, index) => (
                          <tr
                            key={`a_${index}`}
                            className="rowCursorPointer"
                            data-bs-toggle="modal"
                            data-bs-target="#myModal"
                          >
                            <td> </td>

                            <td>
                              <Autocomplete
                                value={
                                  dropdownItems?.find(
                                    (item) => item.ID === element.POD_Selection
                                  ) || null
                                }
                                options={dropdownItems}
                                getOptionLabel={(option) =>
                                  option.produce_name_en || ""
                                }
                                onChange={(event, newValue) =>
                                  addFieldHandleChangeWname(
                                    index,
                                    "POD_Selection",
                                    newValue?.ID || null
                                  )
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    placeholder="Select Item"
                                    variant="outlined"
                                    // label="Select POD"
                                  />
                                )}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_quantity"
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_quantity}
                              />
                            </td>
                            <td>
                              <Autocomplete
                                value={
                                  unitType?.find(
                                    (item) =>
                                      item.unit_id === element.unit_count_id
                                  ) || null
                                }
                                options={unitType}
                                getOptionLabel={(option) =>
                                  option.unit_name_en || ""
                                }
                                onChange={(event, newValue) =>
                                  addFieldHandleChangeWname(
                                    index,
                                    "unit_count_id",
                                    newValue?.unit_id || null
                                  )
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    variant="outlined"
                                    placeholder="Select Unit"
                                  />
                                )}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                name="pod_price"
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_price}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                name="pod_vat"
                                className="border-0"
                                style={{ width: "50px" }}
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_vat}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                readOnly
                                className="border-0"
                                value={(
                                  +(
                                    +element.pod_price *
                                    +element.pod_quantity *
                                    (element.pod_vat / 100)
                                  ) +
                                  +element.pod_price * +element.pod_quantity
                                ).toLocaleString("en-us")}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_wht_id"
                                style={{ width: "50px" }}
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_wht_id}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_crate"
                                className="border-0"
                                style={{ width: "70px" }}
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_crate}
                              />
                            </td>
                            <td>
                              {index == formsValue.length - 1 ? (
                                <button
                                  type="button"
                                  onClick={addFormFields}
                                  className="cursor-pointer"
                                >
                                  <i className="mdi mdi-plus text-xl" />
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  className="cursor-pointer"
                                  onClick={() => removeFormFields(index)}
                                >
                                  <i className="mdi mdi-trash-can-outline text-xl" />
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className="card-footer">
            <button
              className="btn btn-primary"
              type="submit"
              name="signup"
              onClick={update}
              disabled={buttonClicked} // Disable button if it has been clicked
            >
              {from?.po_id ? "Update" : "Create"}
            </button>
            <Link className="btn btn-danger" to={"/purchase_orders"}>
              Cancel
            </Link>
          </div>
        </div>
      </Card>

      <Modal
        className="modalError receiveModal"
        show={show}
        onHide={handleClose}
      >
        <div className="modal-content">
          <div
            className="modal-header border-0"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          >
            <h1 className="modal-title fs-5" id="exampleModalLabel">
              Purchase Order Check
            </h1>
            <button
              style={{ color: "#fff", fontSize: "30px" }}
              type="button"
              // onClick={() => setShow(false)}
              onClick={closeIcon}
            >
              <i class="mdi mdi-close"></i>
            </button>
          </div>
          <div
            className="modal-body"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          >
            <div className="eanCheck errorMessage recheckReceive">
              <p style={{ backgroundColor: color ? "" : "#631f37" }}>
                {stock.message_en ? stock.message_en : "NULL"}
              </p>
              <p style={{ backgroundColor: color ? "" : "#631f37" }}>
                {stock.message_th ? stock.message_th : "NULL"}
              </p>
              <div className="closeBtnRece">
                <button onClick={closeIcon}>Close</button>
              </div>
            </div>
          </div>
          <div
            className="modal-footer"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          ></div>
        </div>
      </Modal>
    </>
  );
};

export default CreatePurchaseOrder;
