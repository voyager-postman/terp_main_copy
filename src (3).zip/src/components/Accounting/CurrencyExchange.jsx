import { useState, useEffect } from "react";
import axios from "axios";
import { API_BASE_URL } from "../../Url/Url";
import { toast } from "react-toastify";
import ReactApexChart from "react-apexcharts";

const CurrencyExchange = () => {
  const [data, setData] = useState([]);
  const [filterValue, setFilterValue] = useState("");
  const [searchApiData, setSearchApiData] = useState([]);
  const [allData, setAllData] = useState([]);
  const [entriesPerPage, setEntriesPerPage] = useState(10);
  const [rangeValue, setRangeValue] = useState("");

  // State for chart data
  const [chartData, setChartData] = useState({
    series: [
      { name: "Desktops", data: [] },
      { name: "Mobile", data: [] },
    ],
    options: {
      chart: { height: 200, type: "line", zoom: { enabled: false } },

      dataLabels: { enabled: false },
      xaxis: { categories: [] }, // Initially empty
      stroke: { curve: "straight" },
      title: { text: "Product Trends by Month", align: "left" },
      grid: { row: { colors: ["#f3f3f3", "transparent"], opacity: 0.5 } },
      colors: [
        "#203764", // Dark Blue
        "#ffc300", // Yellow
        "#2ecc71", // Green
        "#e74c3c", // Red
        "#8e44ad", // Purple
        "#3498db", // Light Blue
        "#f39c12", // Orange
        "#2c3e50", // Dark Grey
        "#d35400", // Pumpkin
        "#27ae60", // Emerald Gre,
      ],
      yaxis: {
        title: { text: "Exchange Rate" },
        labels: { formatter: (value) => `${value}` },
        max: rangeValue.overallMax, // Using value from API
        min: rangeValue.overallMin, // Using value from API
        tickAmount: 3, // Optional: one tick per integer (31 to 37)
      },
    },
  });

  const getAllFx = () => {
    axios
      .get(`${API_BASE_URL}/GetFxRate`)
      .then((res) => {
        setData(res.data.data);
        setSearchApiData(res.data.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the data!", error);
      });
  };

  const getAllFx1 = () => {
    axios
      .get(`${API_BASE_URL}/getFxRateHistoryGraph`)
      .then((res) => {
        console.log(res);
        setRangeValue(res.data);

        const graphDataArray = res.data.data; // Assuming your API response contains an array of objects
        const categories = graphDataArray[0]?.rates.map((item) => item.date); // Extract categories (dates) from the first data item

        // Map through the data dynamically to construct series array
        const dynamicSeries = graphDataArray.map((item) => ({
          name: item.currency, // Get currency name dynamically
          data: item.rates.map((rate) => rate.value), // Get values dynamically
        }));

        console.log(categories);

        // Update chart data dynamically
        setChartData({
          ...chartData,
          series: dynamicSeries, // Use dynamically generated series
          options: {
            ...chartData.options,
            xaxis: {
              categories, // Categories for tooltips, but axis will be hidden
              labels: {
                show: false, // Hide the x-axis labels
              },
              axisBorder: {
                show: false, // Hide the x-axis border
              },
              axisTicks: {
                show: false, // Hide the x-axis ticks
              },
            },
            tooltip: {
              x: {
                show: true, // Show the x-axis categories in the tooltip on hover
              },
            },
          },
        });
      })
      .catch((error) => {
        console.error("There was an error fetching the graph data!", error);
      });
  };

  useEffect(() => {
    getAllFx();
    getAllFx1();
  }, []);

  const handlePriceChange = (index) => (e) => {
    const updatedData = [...data];
    updatedData[index].fx_rate = e.target.value;
    setData(updatedData);
  };

  const handleUpdate = (item) => {
    axios
      .post(`${API_BASE_URL}/updateFxRateHistory`, {
        fx_id: item.fx_id,
        fx_rate: item.fx_rate,
      })
      .then((response) => {
        getAllFx();
        toast.success("Update successful");
      })
      .catch((error) => {
        toast.error("Update failed");
      });
  };

  const handleFilter = (event) => {
    if (event.target.value === "") {
      setData(searchApiData);
    } else {
      const filterResult = searchApiData.filter((item) => {
        return item.currency_name
          .toLowerCase()
          .includes(event.target.value.toLowerCase());
      });
      setData(filterResult);
    }
    setFilterValue(event.target.value);
  };

  const handleEntriesChange = (event) => {
    setEntriesPerPage(Number(event.target.value));
  };

  return (
    <div>
      <div className="container-fluid">
        <div>
          <main className="main-content">
            <div>
              <div className="px-0">
                <div className="row">
                  <div className="col-lg-12 col-md-12 mb-4">
                    <div className="bg-white">
                      <div className="databaseTableSection pt-0">
                        <div className="grayBgColor p-4 pb-2">
                          <div className="row">
                            <div className="col-md-6">
                              <h6 className="font-weight-bolder mb-0 pt-2">
                                Currency Exchange Update
                              </h6>
                            </div>
                          </div>
                        </div>
                        <div className="top-space-search-reslute">
                          <div className="tab-content px-2 md:!px-4">
                            <div className="parentProduceSearch">
                              <div className="entries">
                                <small>Show</small>{" "}
                                <select
                                  value={entriesPerPage}
                                  onChange={handleEntriesChange}
                                >
                                  <option value={10}>10</option>
                                  <option value={25}>25</option>
                                  <option value={50}>50</option>
                                  <option value={100}>100</option>
                                </select>{" "}
                                <small>entries</small>
                              </div>
                              <div>
                                <input
                                  type="search"
                                  placeholder="search"
                                  value={filterValue}
                                  onChange={(e) => handleFilter(e)}
                                />
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-lg-6 currencySec">
                                <div
                                  className="tab-pane active"
                                  id="header"
                                  role="tabpanel"
                                >
                                  <div
                                    id="datatable_wrapper"
                                    className="information_dataTables dataTables_wrapper dt-bootstrap4 table-responsive"
                                  >
                                    <div className="d-flex exportPopupBtn" />
                                    <table
                                      id="example"
                                      className="display updatePriceTable table table-hover table-striped borderTerpProduce"
                                      style={{ width: "50%" }}
                                    >
                                      <thead>
                                        <tr>
                                          <th className="fiftyPer">
                                            <table>
                                              <tbody>
                                                <tr>
                                                  <th
                                                    colSpan={3}
                                                    style={{
                                                      textAlign: "left",
                                                    }}
                                                  >
                                                    Updated Price
                                                  </th>
                                                </tr>
                                                {data
                                                  .slice(0, entriesPerPage)
                                                  .map((item, index) => (
                                                    <tr key={index}>
                                                      <td>
                                                        {item.currency_name}
                                                      </td>
                                                      <td>
                                                        <div className="form-group col-lg-3 formCreate mt-0">
                                                          <input
                                                            className="mb-0 w-full"
                                                            name="fx_rate"
                                                            value={
                                                              item.fx_rate || ""
                                                            }
                                                            onChange={handlePriceChange(
                                                              index
                                                            )}
                                                            style={{
                                                              width: 250,
                                                            }}
                                                          />
                                                        </div>
                                                      </td>
                                                      <td>
                                                        <div className="btnUpdate">
                                                          <button
                                                            onClick={() =>
                                                              handleUpdate(item)
                                                            }
                                                          >
                                                            Update
                                                          </button>
                                                        </div>
                                                      </td>
                                                    </tr>
                                                  ))}
                                              </tbody>
                                            </table>
                                          </th>
                                        </tr>
                                      </thead>
                                    </table>
                                  </div>
                                </div>
                              </div>
                              <div className="col-lg-6">
                                <div className="currecyGraph">
                                  <div>
                                    <div id="chart">
                                      <ReactApexChart
                                        options={chartData.options}
                                        series={chartData.series}
                                        type="line"
                                        height={350}
                                      />
                                    </div>
                                    <div id="html-dist"></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default CurrencyExchange;
