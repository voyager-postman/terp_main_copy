const ClaimDetails = () => {
	return <div>ClaimDetails</div>
}

export default ClaimDetails
