import axios from "axios";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../../Url/Url";
import { Card } from "../../../card";
import MySwal from "../../../swal";
import { Button, Modal } from "react-bootstrap";
export const OrderPackagingEdit = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const { from } = location.state || {};
  console.log(from);

  const loadingModal = MySwal.mixin({
    title: "Loading...",
    didOpen: () => {
      MySwal.showLoading();
    },
    showCancelButton: false,
    showConfirmButton: false,
    allowOutsideClick: false,
  });
  const isReadOnly = from?.isReadOnly;
  const [isLoading, setIsLoading] = useState(false);
  const [stock, setStock] = useState("");
  const [details, setDetails] = useState([]);
  const [tableHeader, setTableHeader] = useState("");

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [bonus, setBonus] = useState("");
  const [adjustedId, setAdjustedId] = useState("");
  const [disabledButtons, setDisabledButtons] = useState([]);
  const [disabledPackagingButtons, setDisabledPackagingButtons] = useState([]);

  const getOrdersDetails = () => {
    axios
      .get(`${API_BASE_URL}/getOrderPackingDetails`, {
        params: {
          id: from?.Order_ID,
        },
      })
      .then((response) => {
        console.log(response);
        setDetails(response.data.data || []);
        setTableHeader(response.data.table_head);
      })
      .catch((e) => {});
  };

  // const handleEditValues = (index, e) => {
  //   if (isReadOnly || isLoading) return;
  //   const newEditProduce = [...details];
  //   newEditProduce[index][e.target.name] = e.target.value;
  //   setDetails(newEditProduce);
  // };
  const handleEditValues = async (index, e) => {
    if (isReadOnly || isLoading) return;

    const { name, value } = e.target;
    const newEditProduce = [...details];
    newEditProduce[index][name] = value;
    setDetails(newEditProduce);

    const updatedRow = newEditProduce[index];

    // Dynamically set payload based on input name
    const payload = {
      OD_ID: updatedRow.col2,
    };

    if (name === "col7") {
      payload.ean_required = value;
    } else if (name === "col15") {
      payload.bonus = value;
    } else if (name === "col16") {
      payload.adjusted_gw_od = value;
    }

    try {
      await axios.post(`${API_BASE_URL}/updatedoOrderPacking`, payload);
      // Optional: Refresh or notify
    } catch (error) {
      console.error("Failed to update packing:", error);
    }
  };

  const { data: unit } = useQuery("getAllUnit");
  const { data: itf } = useQuery("getItf");

  const getDetails = async (orderId, odId) => {
    // try {
    //   const response = await axios.post(`${API_BASE_URL}/getOrderPacking`, {
    //     order_id: orderId,
    //     od_id: odId,
    //   });
    //   console.log(response);
    //   if (response.data.data.buns !== undefined) {
    //     // Merge the new bonus and adjusted_gw_od values with the existing details array
    //     setDetails((prevDetails) =>
    //       prevDetails.map((item) =>
    //         item.order_id === orderId && item.od_id === odId
    //           ? {
    //               ...item,
    //               bonus: response.data.data.buns,
    //               adjusted_gw_od: response.data.data.adjusted_gw_od,
    //               order_packing_id: response.data.data.order_packing_id,
    //               ean_per_od: response.data.data.new_pc_od,
    //               Number_of_boxes: response.data.data.new_box_od,
    //               net_weight: response.data.data.new_nw_od,
    //             }
    //           : item
    //       )
    //     );
    //   }
    // } catch (error) {
    //   console.error("Error fetching data:", error);
    // }
  };

  useEffect(() => {
    getOrdersDetails();
    details.forEach((v) => {
      if (+v.status !== 1 && !v.bonus && !v.adjusted_gw_od) {
        getDetails(v.order_id, v.od_id); // Call getDetails with orderId and odId
      }
    });
  }, []);
  console.log(stock);
  console.log(bonus, adjustedId);
  const doPackaging = async (index, orderId) => {
    const data = details[index];
    console.log(data);

    setIsLoading(true);
    loadingModal.fire();

    try {
      // Replace the key EAN_To_Pack with ean_per_od in the data object

      await axios
        .post(`${API_BASE_URL}/doOrderPacking`, {
          od_id: orderId,
          user_id: localStorage.getItem("id"),
        })
        .then((response) => {
          console.log(response);
          setDetails(response.data.data || []);
        })
        .then((response) => {
          console.log(response);
          toast.success("Order packaged successfully", {
            theme: "colored",
          });
          getOrdersDetails();
        });
    } catch (e) {
      console.log(e);
      if (e.response && e.response.status === 400) {
        console.log(e.response.data.message);
        setStock(e.response.data.message);
        console.log(">>>>>>>>>>>>");
        // Open a modal here
        setShow(true);
      } else {
        toast.error("Something went wrong", {
          theme: "colored",
        });
      }
    } finally {
      loadingModal.close();
      setIsLoading(false);

      // Disable the button after it's clicked
      setDisabledPackagingButtons((prevDisabledButtons) => [
        ...prevDisabledButtons,
        index,
      ]);
    }
  };

  const restoreOrderPackaging = (id, id1, index) => {
    console.log(id);
    // Check if the button is already disabled
    if (disabledButtons.includes(index)) {
      return;
    }

    // Disable the button
    setDisabledButtons((prevDisabledButtons) => [
      ...prevDisabledButtons,
      index,
    ]);

    axios
      .post(`${API_BASE_URL}/RestoreOrderPacking`, {
        order_id: id,
        od_id: id1,
        user_id: localStorage.getItem("id"),
      })
      .then((response) => {
        console.log(response);
        if (response?.data?.success == false) {
          toast.warn(response.data.message, {
            autoClose: 1000,
            theme: "colored",
          });
          getOrdersDetails();
        }
        console.log(response);
        if (response?.data?.success == true) {
          toast.success(response.data.message, {
            autoClose: 1000,
            theme: "colored",
          });
          getOrdersDetails();
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const formatterThree = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 3,
    maxmumFractionDigits: 3,
  });
  //  const formatterNo = new Intl.NumberFormat("en-US", {
  //   style: "decimal",
  //   minimumFractionDigits: 0,
  //   maxmumFractionDigits: 0,
  // });

  const formatterNo = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });

  return (
    <>
      <Card title="Expense Item Management / Edit Form">
        <div
          id="datatable_wrapper"
          className="information_dataTables dataTables_wrapper dt-bootstrap4 px-4"
        >
          <div className="formCreate ">
            <form action="">
              <div className="row formEan">
                <div className="col-lg-3 form-group">
                  <h6> Order Code </h6>
                  <input
                    readOnly
                    className="border-0"
                    value={from?.Order_Number || ""}
                  />
                </div>
                <div className="col-lg-3 form-group">
                  <h6>Shipment Ref </h6>
                  <input
                    readOnly
                    className="border-0"
                    value={from?.Shipment_ref || ""}
                  />
                </div>
                <div className="col-lg-3 form-group">
                  <h6> Load Date </h6>
                  <input
                    readOnly
                    className="border-0"
                    value={
                      from?.load_date
                        ? new Date(from?.load_date).toLocaleDateString()
                        : ""
                    }
                  />
                </div>
                <div className="col-lg-3 form-group">
                  <h6> Load Time </h6>
                  <input
                    readOnly
                    className="border-0"
                    value={
                      from?.load_date
                        ? new Date(from?.load_date).toLocaleTimeString()
                        : ""
                    }
                  />
                </div>
              </div>
              <div
                id="datatable_wrapper"
                className="orderPackingEdit information_dataTables dataTables_wrapper dt-bootstrap4 table-responsive mt-"
              >
                <table
                  id="example"
                  className="display transPortCreate table table-hover table-striped borderTerpProduce table-responsive"
                  style={{ width: "100%" }}
                >
                  {/* <thead>
                    <tr>
                      <th>ITF</th>
                      <th> Brand </th>
                      <th>% Completed</th>
                      <th>EAN Required</th>
                      <th>EAN Packed</th>
                      <th>EAN to Pack</th>
                      <th>Net weight Required</th>
                      <th>Net weight Packed</th>
                      <th>Net weight to Pack</th>
                      <th>Number of Box</th>
                      <th>Buns</th>
                      <th>Weight Adjustment</th>
                      <th>Action</th>
                    </tr>
                  </thead> */}
                  <thead>
                    <tr>
                      {tableHeader &&
                        Object.entries(tableHeader)
                          .filter(
                            ([key]) =>
                              !["Order_ID", "OD ID", "Status"].includes(key)
                          )
                          .map(([key, label]) => <th key={key}>{label}</th>)}
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>
                    {details.map((v, i) => {
                      if (+v.status !== 1 && !v.bonus && !v.adjusted_gw_od) {
                        getDetails(v.order_id, v.od_id); // Call getDetails with orderId and odId
                      }

                      return (
                        <tr className="rowCursorPointer align-middle" key={i}>
                          <td className="text-start">{v.col3}</td>
                          <td className="text-center">
                            <>{v.col4}</>
                          </td>
                          <td className="text-center">
                            <>{v.col5}</>
                          </td>
                          <td className="text-center">
                            <>{formatterThree.format(v.col6)}</>
                          </td>
                          <td className="text-end">
                            <td className="text-end">
                              {v.col17 === 0 ? (
                                <input
                                  type="number"
                                  className="!w-24 mb-0"
                                  onChange={(e) => handleEditValues(i, e)}
                                  value={v.col7}
                                  name="col7" // Match this with what you're updating
                                />
                              ) : (
                                formatterNo.format(parseFloat(v.col7) || 0)
                              )}
                            </td>
                          </td>
                          <td className="text-end">
                            <>{formatterThree.format(v.col8)}</>
                          </td>
                          <td className="text-end">
                            {/* {v.col17 === 1 ? (
                              <input
                                type="number"
                                className="!w-24 mb-0"
                                onChange={(e) => handleEditValues(i, e)}
                                value={v.col9}
                                name="EAN_To_Pack"
                              />
                            ) : ( */}
                            <>{formatterThree.format(v.col9)}</>
                            {/* )} */}
                          </td>
                          <td className="text-end">
                            <>{formatterThree.format(v.col10)}</>
                          </td>
                          <td className="text-end">
                            <>{formatterThree.format(v.col11)}</>
                          </td>
                          <td className="text-end">
                            <>{formatterThree.format(v.col12)}</>
                          </td>
                          <td className="text-end">
                            {/* {v.col17 === 1 ? (
                              <input
                                type="number"
                                className="!w-24 mb-0"
                                onChange={(e) => handleEditValues(i, e)}
                                value={v.col13}
                                name="NW_To_Pack"
                              />
                            ) : ( */}
                            {formatterThree.format(parseFloat(v.col13) || 0)}
                            {/* )} */}
                          </td>

                          <td className="text-end">
                            {/* {v.col17 === 1 ? (
                              <input
                                type="number"
                                className="!w-24 mb-0"
                                onChange={(e) => handleEditValues(i, e)}
                                value={v.col14}
                                name="Boxes"
                              />
                            ) : ( */}
                            {formatterNo.format(parseFloat(v.col14) || 0)}
                            {/* )} */}
                          </td>

                          <td className="text-end">
                            {/* {v.col17 === 1 ? (
                              <input
                                type="number"
                                className="!w-24 mb-0"
                                onChange={(e) => handleEditValues(i, e)}
                                value={v.col15}
                                name="bonus"
                              />
                            ) : ( */}
                            {v.col17 === 1 ? (
                              <input
                                type="number"
                                className="!w-24 mb-0"
                                onChange={(e) => handleEditValues(i, e)}
                                value={v.col15}
                                name="col15" // Match this with what you're updating
                              />
                            ) : (
                              formatterNo.format(parseFloat(v.col15) || 0)
                            )}

                            {/* {formatterNo.format(parseFloat(v.col15) || 0)} */}
                            {/* )} */}
                          </td>

                          <td className="text-end">
                            {/* {v.col17 === 1 ? (
                              <input
                                type="number"
                                className="!w-24 mb-0"
                                onChange={(e) => handleEditValues(i, e)}
                                value={v.col16}
                                name="adjusted_gw_od"
                              />
                            ) : ( */}
                            {/* {formatterNo.format(parseFloat(v.col16) || 0)}
                             */}
                            {/* )} */}
                            {v.col17 === 1 ? (
                              <input
                                type="number"
                                className="!w-24 mb-0"
                                onChange={(e) => handleEditValues(i, e)}
                                value={v.col16}
                                name="col16" // Match this with what you're updating
                              />
                            ) : (
                              formatterNo.format(parseFloat(v.col16) || 0)
                            )}
                          </td>

                          <td>
                            {!isReadOnly && +v.col17 === 0 && (
                              <button
                                type="button"
                                // disabled={disabledPackagingButtons.includes(i)}
                                className="py-1"
                                onClick={() => doPackaging(i, v.col2)}
                              >
                                <i className="mdi mdi-package-variant-closed text-2xl"></i>
                              </button>
                            )}

                            {!isReadOnly && +v.col17 === 1 && (
                              <button
                                type="button"
                                // disabled={disabledButtons.includes(i)}
                                onClick={() => {
                                  restoreOrderPackaging(v.col1, v.col2, i);
                                }}
                              >
                                <i
                                  className="mdi mdi-restore"
                                  style={{
                                    width: "20px",
                                    color: "#203764",
                                    fontSize: "22px",
                                    marginTop: "10px",
                                  }}
                                />
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </form>
          </div>
        </div>
        <div className="card-footer">
          <Link className="btn btn-danger" to={"/orderPackaging"}>
            Cancel
          </Link>
        </div>
        <Modal className="modalError" show={show} onHide={handleClose}>
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Stock Check
              </h1>
              <button
                style={{ color: "#fff", fontSize: "30px" }}
                type="button"
                onClick={() => setShow(false)}
              >
                <i class="mdi mdi-close"></i>
              </button>
            </div>
            <div className="modal-body">
              <div className="eanCheck errorMessage">
                <p>{stock.message ? stock.message : "NULL"}</p>
                <p>{stock.message2 ? stock.message2 : "NULL"}</p>
                <p>{stock.message3 ? stock.message3 : "NULL"}</p>
              </div>
            </div>
            <div className="modal-footer"></div>
          </div>
        </Modal>
      </Card>
    </>
  );
};
