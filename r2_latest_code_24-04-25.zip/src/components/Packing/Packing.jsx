import { useForm } from "@tanstack/react-form";
import axios from "axios";
import { useMemo, useState, useEffect } from "react";
import { useQuery } from "react-query";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { TableView } from "../table";
import CloseIcon from "@mui/icons-material/Close";

const EanPacking = () => {
  const [data, setData] = useState([]);
  const getEanPackaging = () => {
    axios.get(`${API_BASE_URL}/getToPack`).then((res) => {
      setData(res.data.data || []);
    });
  };

  useEffect(() => {
    getEanPackaging();
  }, []);
  const formatTwoDecimals = (value) => {
    return new Intl.NumberFormat(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value); // <-- .format moved here inside the function
  };
  const [id, setId] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const [restoredRows, setRestoredRows] = useState([]);

  const form = useForm({
    defaultValues: {
      user_id: localStorage.getItem("id"),
      sorting_id: id,
      Quantity_on_Hand: "",
      Crates_on_Hand: "",
    },
    onSubmit: async ({ value }) => {
      try {
        const response = await axios.post(`${API_BASE_URL}/SortingStockWaste`, {
          ...value,
          Quantity_on_Hand: parseInt(value.Qty_on_hand, 10),
          Crates_on_Hand: parseInt(value.Crates_on_hand, 10),
        });
        console.log(response.status); // Log the response object
        if (response.status == 200) {
          toast.success("Ean Packing update successful");
          getEanPackaging();
          setIsOpen(false);
        }
      } catch (error) {
        toast.error("Something went wrong");
      }
    },
  });

  const closeModal = () => {
    setIsOpen(false);
  };

  const openModal = (id = null) => {
    setId(id);
    form.reset();
    setIsOpen(true);
  };

  const restoreEanPackage = (id, id1) => {
    if (restoredRows.includes(id)) {
      return; // Do nothing if already restored
    }

    axios
      .post(`${API_BASE_URL}/restoreEanPacking`, {
        sorting_id: id,
        pod_code: id1,
        user_id: localStorage.getItem("id"),
      })
      .then((response) => {
        if (response?.data?.success == false) {
          toast.warn(response.data.message, {
            autoClose: 1000,
            theme: "colored",
          });
          getEanPackaging();
        }
        console.log(response);
        if (response?.data?.success == true) {
          getEanPackaging();
          toast.success(response.data.message, {
            autoClose: 1000,
            theme: "colored",
          });
        }

        setRestoredRows([...restoredRows, id]);
      })
      .catch((error) => {
        getEanPackaging();
        console.log(error);
      });
  };
  const columns = useMemo(
    () => [
      {
        Header: () => <div style={{ textAlign: "center" }}>PO CODE</div>,
        accessor: "PODCODE",
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Vender Name</div>,
        accessor: "Vendor_Name",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        // if your table supports it
      },
      {
        Header: () => <div style={{ textAlign: "center" }}> Name</div>,

        accessor: "Name_EN",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        headerStyle: { textAlign: "left" },
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Date</div>,
        accessor: (row) => new Date(row.Date).toLocaleDateString(),
        id: "Date", // important when using function accessor
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Crates</div>,
        accessor: "Crates",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>
            {formatTwoDecimals(value)}{" "}
            {/* <-- correctly calling the function */}
          </div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Quantity</div>,
        accessor: "Quantity",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Unit</div>,
        accessor: "Unit",
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Cost</div>,
        accessor: "Cost",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>QTY / Crate</div>,

        accessor: "Qty/Crate",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Status</div>,

        accessor: "Status",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        headerStyle: { textAlign: "left" },
      },

      {
        Header: "Actions",
        accessor: (a) => {
          return (
            <>
              <Link state={{ from: a }} to="/newEanPacking">
                <i
                  className="mdi mdi-check"
                  style={{
                    width: "20px",
                    color: "#203764",
                    fontSize: "22px",
                    marginTop: "10px",
                  }}
                />
              </Link>
              <button type="button" onClick={() => openModal(a.sorting_id)}>
                <i
                  className="mdi mdi-delete"
                  style={{
                    width: "20px",
                    color: "#203764",
                    fontSize: "22px",
                    marginTop: "10px",
                  }}
                />
              </button>
              <button
                type="button"
                onClick={() => restoreEanPackage(a.sorting_id, a.pod_code)}
                disabled={restoredRows.includes(a.sorting_id)}
              >
                <i
                  className="mdi mdi-restore"
                  style={{
                    width: "20px",
                    color: "#203764",
                    fontSize: "22px",
                    marginTop: "10px",
                  }}
                />
              </button>
            </>
          );
        },
      },
    ],
    [restoredRows]
  );
  // const columns = useMemo(
  //   () => [
  //     {
  //       Header: "Code",
  //       accessor: "pod_code",
  //       className: "poCode",
  //     },
  //     {
  //       Header: "Name",
  //       accessor: "produce",
  //     },
  //     {
  //       Header: "Quantity",
  //       accessor: "available_qty",
  //     },
  //     {
  //       Header: "Unit",
  //       accessor: "Unit",
  //     },
  //     {
  //       Header: "Cost",
  //       accessor: "sorted_cost",
  //     },
  //     {
  //       Header: "Actions",
  //       accessor: (a) => {
  //         return (
  //           <>
  //             <Link state={{ from: a }} to="/newEanPacking">
  //               <i
  //                 className="mdi mdi-check"
  //                 style={{
  //                   width: "20px",
  //                   color: "#203764",
  //                   fontSize: "22px",
  //                   marginTop: "10px",
  //                 }}
  //               />
  //             </Link>
  //             <button type="button" onClick={() => openModal(a.sorting_id)}>
  //               <i
  //                 className="mdi mdi-delete"
  //                 style={{
  //                   width: "20px",
  //                   color: "#203764",
  //                   fontSize: "22px",
  //                   marginTop: "10px",
  //                 }}
  //               />
  //             </button>
  //             <button
  //               type="button"
  //               onClick={() => restoreEanPackage(a.sorting_id, a.pod_code)}
  //               disabled={restoredRows.includes(a.sorting_id)}
  //             >
  //               <i
  //                 className="mdi mdi-restore"
  //                 style={{
  //                   width: "20px",
  //                   color: "#203764",
  //                   fontSize: "22px",
  //                   marginTop: "10px",
  //                 }}
  //               />
  //             </button>
  //           </>
  //         );
  //       },
  //     },
  //   ],
  //   [restoredRows]
  // );

  return (
    <>
      <Card title="Packing Management">
        <TableView columns={columns} data={data} />
      </Card>
      {isOpen && (
        <div className="fixed inset-0 flex items-center justify-center modalEanEdit">
          <div
            className="fixed w-screen h-screen bg-black/20"
            onClick={closeModal}
          />
          <div className="bg-white rounded-lg shadow-lg max-w-md w-full">
            <div className="crossArea">
              <h3>Edit Details</h3>
              <p onClick={closeModal}>
                <CloseIcon />
              </p>
            </div>
            <form.Provider>
              <form
                className="formEan formCreate p-0"
                onSubmit={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  void form.handleSubmit();
                }}
              >
                <div className="p-3">
                  <div className="form-group">
                    <label>Quantity on Hand</label>
                    <form.Field
                      name="Qty_on_hand "
                      children={(field) => (
                        <input
                          type="number"
                          name={field.name}
                          value={field.state.value}
                          onBlur={field.handleBlur}
                          onChange={(e) => field.handleChange(e.target.value)}
                        />
                      )}
                    />
                  </div>
                  <div className="form-group">
                    <label>Crates on Hand</label>
                    <form.Field
                      name="Crates_on_hand "
                      children={(field) => (
                        <input
                          type="number"
                          name={field.name}
                          value={field.state.value}
                          onBlur={field.handleBlur}
                          onChange={(e) => field.handleChange(e.target.value)}
                        />
                      )}
                    />
                  </div>
                </div>
                <div className="modal-footer d-flex justify-content-center">
                  <div className="flex gap-2 justify-end">
                    <button
                      type="button"
                      className="bg-gray-300 px-4 py-2 rounded"
                      onClick={closeModal}
                    >
                      Close
                    </button>

                    <button
                      type="submit"
                      className="bg-black text-white px-4 py-2 rounded"
                    >
                      Save
                    </button>
                  </div>
                </div>
              </form>
            </form.Provider>
          </div>
        </div>
      )}
    </>
  );
};

export default EanPacking;
