import axios from "../../Url/Api";
import { useState, useEffect, useMemo } from "react";
import { useQuery } from "react-query";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import MySwal from "../../swal";
import { ComboBox } from "../combobox";
import { TableView } from "../table";
import CloseIcon from "@mui/icons-material/Close";
import { useTranslation } from "react-i18next";

import {
  LocalizationProvider,
  DesktopDateTimePicker,
} from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import { Autocomplete } from "@mui/material";

const EanRepack = () => {
  const { t, i18n } = useTranslation("global");
  const role = localStorage.getItem("role");
  const email = localStorage.getItem("email");

  const location = useLocation();
  const navigate = useNavigate();
  const { from } = location.state || {};
  console.log(from);
  const [closeButton, setCloseButton] = useState(true);
  const [isOpenModal, setIsOpenModal] = useState(false);
  const [eanListData, setEanListData] = useState([]);
  const [pcId, setPcId] = useState("");

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedDate1, setSelectedDate1] = useState(new Date());

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };
  console.log(from?.Produce_id);
  const eanList = () => {
    axios
      .post(`${API_BASE_URL}/PEANDropdownList`, {
        produce_id: from?.Produce_id,
      })
      .then((response) => {
        console.log(response.data);
        setEanListData(response.data.data);
      })
      .catch((error) => {
        console.error("There was an error updating the data!", error);
      });
  };
  useEffect(() => {
    eanList();
  }, []);
  const options =
    eanListData?.map((item) => ({
      id: item.ID,
      name:
        (email === "Plaew" && role === "Operation") ||
          (email === "Gam" && role === "Operation") ||
          (email === "Look Sorn" && role === "Operation")
          ? item.EAN_Internal_TH
          : item.EAN_Internal_EN,
    })) || [];

  const handleDateChange1 = (date) => {
    setSelectedDate1(date);
  };
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    };
    const formattedDate = date
      .toLocaleString("en-GB", options)
      .replace(",", "");
    return formattedDate.replace(/\//g, "-");
  };
  const loadingModal = MySwal.mixin({
    title: "Loading...",
    didOpen: () => {
      MySwal.showLoading();
    },
    showCancelButton: false,
    showConfirmButton: false,
    allowOutsideClick: false,
  });

  const openModal = () => {
    setIsOpenModal(true);
  };

  const closeModal = () => {
    setIsOpenModal(false);
    setData("");
  };

  const defaultState = {
    pod_code: from?.pod_code,
    sorting_id: from?.sorting_id,
    oldqty: from?.qty_available,
    user_id: localStorage.getItem("id"),
    number_of_staff: "",
    start_time: "",
    end_time: "",
  };

  const defaultData = {
    ean_id: null,
    unit_id: null,
    brand_id: null,
    ean_quantity: 0,
  };

  const [state, setState] = useState(defaultState);
  const [toggle, setToggle] = useState(false);
  const [data, setData] = useState(defaultData);
  // const [filterdata, setFilterdata] = useState("");

  const [packingCommonId, setPackingCommonId] = useState(null);
  const [datatable, setDatatable] = useState([]);
  const [assigned, setAssigned] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState("");
  console.log(state.start_time);
  const { data: unitType } = useQuery("getAllUnit");
  const { data: brands } = useQuery("getBrand");
  const { data: eanData } = useQuery("getEan");
  console.log(packingCommonId);

  useEffect(() => {
    getPackingCommon();
  }, []);

  useEffect(() => {
    if (packingCommonId) {
      getDatatable(packingCommonId);
    }

    setState((prevState) => ({ ...prevState, defaultData }));
  }, [toggle === true]);

  const getPackingCommon = () => {
    const request = {
      pod_code: from?.pod_code,
      sorting_id: from?.sorting_id,
    };

    loadingModal.fire();

    axios.post(`${API_BASE_URL}/getPackingCommon`, request).then((response) => {
      console.log(response);
      if (response.data.data) {
        const { packing_common_id, number_of_staff, start_time, end_time } =
          response.data.data;

        // setPackingCommonId((prevState) => packing_common_id);
        setState((prevState) => {
          return {
            ...prevState,
            number_of_staff: "",
            start_time: "",
            end_time: "",
          };
        });

        // getDatatable(packing_common_id);
      }

      MySwal.close();
    });
  };

  const getDatatable = async (packing_common_id) => {
    await axios
      .post(`${API_BASE_URL}getEanDetailViews`, {
        packing_common_id: packing_common_id,
      })
      .then((response) => {
        console.log(response);
        if (response.data.data) {
          setDatatable(response.data.data);
        }
      });
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setState((prevState) => {
      return {
        ...prevState,
        [name]: value,
      };
    });
  };

  const handleChangeData = (e, name) => {
    setData((prevState) => ({ ...prevState, [name]: e }));
  };

  const handleChangeQty = (e) => {
    setData((prevState) => ({ ...prevState, ean_quantity: e.target.value }));
  };

  const checkPackCommonId = async () => {
    try {
      const res = await axios.post(`${API_BASE_URL}/CheckstartEndTime`, {
        start_time: formatDate(selectedDate1),
        end_time: formatDate(selectedDate),
      });

      const responseData = res.data;

      if (responseData.success === true) {
        if (!packingCommonId) {
          const { oldqty, number_of_staff } = state;

          if (!oldqty || !number_of_staff || !selectedDate || !selectedDate1) {
            return toast.error(t("genericError")); // or a specific message
          }
        }
        console.log(localStorage); // View all keys

        // Proceed with repack API call
        const repackRes = await axios.post(`${API_BASE_URL}/doRepackEan`, {
          number_of_staff: state.number_of_staff,
          packing_ean_id: from?.packing_ean_id,
          start_time: formatDate(selectedDate1),
          end_time: formatDate(selectedDate),
          user_id: localStorage.getItem("id"),
          oldqty: state.oldqty,
          PODCODE: from?.pod_code,
          packing_common_id: from?.packing_common_id,
          PC_ID: pcId,
        });
        console.log(repackRes);
        setPcId(repackRes.data.data);
        setCloseButton(false);
        openModal();
      } else {
        closeModal();
        const message = `${responseData.message.en?.trim() || ""} ${responseData.message.th?.trim() || ""
          }`;
        toast.error(message.trim(), {
          className: "toast-error",
        });
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error(t("genericError"));
    }
  };

  const calculate = async () => {
    loadingModal.fire();

    await axios
      .post(`${API_BASE_URL}createEanPacking`, {
        packing_common_id: packingCommonId,
        number_of_staff: state.number_of_staff,
        packing_ean_id: from?.packing_ean_id,
        start_time: formatDate(selectedDate1),
        end_time: formatDate(selectedDate),
        user_id: localStorage.getItem("id"),
        oldqty: state.oldqty,
        PODCODE: from?.pod_code,
      })
      .then((response) => {
        if (response.status === 200) {
          setCloseButton(true);
          // toast.success(t("returnToSupplierSuccess"));
          toast.success("Ean updated successfully");
          setToggle(!toggle);
        }
      });

    MySwal.close();
  };

  const saveNewDetails = async () => {
    const { ean_id, unit_id, brand_id, ean_quantity } = data;

    if (!unit_id || brand_id === null || !ean_quantity) {
      return toast.error(t("pleaseFillAllFields"));
    }

    const request = {
      ean_id: ean_id,
      ean_unit: unit_id,
      ean_brand: brand_id,
      ean_qty: ean_quantity,
      packing_ean_id: from?.packing_ean_id,
      number_of_staff: state.number_of_staff,
      start_time: formatDate(selectedDate1),
      end_time: formatDate(selectedDate),
      user_id: localStorage.getItem("id"),
      assigned_order: selectedOrder,
      oldqty: state.oldqty,
      PODCODE: from?.pod_code,
      packing_common_id: from?.packing_common_id,
      OD_ID: selectedOrder,
      PC_ID: pcId,
    };

    axios
      .post(`${API_BASE_URL}/doRepackEanDetails`, request)
      .then((response) => {
        console.log(response);
        setPackingCommonId(response.data.packing_common_id);

        if (response.status === 200) {
          toast.success(t("eanRepackSuccess"));
          closeModal();
          setToggle(!toggle);
          setCloseButton(true);
          setData({
            ean_id: "",
            unit_id: "",
            brand_id: null,
            ean_quantity: "",
          });
          setSelectedOrder("");
        }
      })
      .catch((error) => {
        return toast.error(error);
      });
  };

  // const handleNewSlecter = () => {
  //   axios
  //     .post(`${API_BASE_URL}/AssignOrderDropDownList`, {
  //       produce_id: from?.Produce_id,
  //     })
  //     .then((response) => {
  //       console.log(response.data.data[0], "this is new item");
  //       setAssigned(response.data.data[0]);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };
  // useEffect(() => {
  //   handleNewSlecter();
  // }, []);

  console.log(selectedOrder, "this is selected value");
  const formatDate1 = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are 0-based
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };
  const formatterTwo = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const formatTwoDecimals = (value) => {
    return new Intl.NumberFormat(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };
  useEffect(() => {
    console.log(data.brand_id);
    console.log(data?.ean_id);
    if (data?.ean_id && data?.brand_id) {
      // Call the PEANORDER API
      fetchPEANORDER(data.ean_id, data.brand_id);
    }
  }, [data?.ean_id, data?.brand_id]);

  const fetchPEANORDER = (eanId, brandId) => {
    axios
      .post(`${API_BASE_URL}/PEANORDER`, {
        EAN: eanId,
        Brand: brandId,
      })
      .then((res) => {
        setAssigned(res?.data?.data);
        console.log("PEANORDER API response:", res.data);
        // Handle response if needed
      })
      .catch((err) => {
        console.error("Error calling PEANORDER:", err);
      });
  };
  const getPackingCommonCancel = async () => {
    console.log(packingCommonId);
    try {
      loadingModal.fire(); // Show loading modal
      if (packingCommonId) {
        const response = await axios.post(`${API_BASE_URL}/PEANRESTORE`, {
          packing_common_id: packingCommonId,
        });

        console.log(response);

        if (response.data?.message === "success") {
          toast.success(t("packingFetchSuccess"), {
            position: "top-right",
            autoClose: 3000,
          });

          // Optional: you can handle response data here
          // setData(response.data.data);
        }
      }

      // 3. Navigate after everything
      navigate("/adjustEan");
    } catch (error) {
      console.error("Error in getPackingCommonCancel:", error);
      toast.error(t("packingFetchFail"));
    } finally {
      loadingModal.close(); // Always close modal
    }
  };
  return (
    <main className="main-content">
      <div>
        <nav
          className="navbar navbar-main navbar-expand-lg px-0 shadow-none border-radius-xl"
          id="navbarBlur"
          navbar-scroll="true"
        >
          <div className="container-fluid py-1 px-0">
            <nav aria-label="breadcrumb"></nav>
          </div>
        </nav>

        <div className="container-fluid pt-1 py-4 px-0">
          <div className="row">
            <div className="col-lg-12 col-md-12 mb-4">
              <div className="bg-white">
                <div className="databaseTableSection pt-0">
                  <div className="grayBgColor" style={{ padding: "18px" }}>
                    <div className="row">
                      <div className="col-md-6">
                        <h6 className="font-weight-bolder mb-0">
                          {" "}
                          {t("rePacking")}
                        </h6>
                      </div>
                    </div>
                  </div>
                  <div className="top-space-search-reslute p-2">
                    <div className="tab-content px-2 md:!px-4">
                      <div
                        className="tab-pane active"
                        id="header"
                        role="tabpanel"
                      >
                        <div
                          id="datatable_wrapper"
                          className="information_dataTables dataTables_wrapper dt-bootstrap4"
                        >
                          <div className="formCreate">
                            <div className="row">
                              <div className="form-group col-lg-3">
                                <div className="parentPurchaseView">
                                  <div className="me-3">
                                    <strong>
                                      {t("podCode")} <span>:</span>
                                    </strong>
                                  </div>
                                  <div>
                                    <p>{from?.pod_code}</p>
                                  </div>
                                </div>
                                <div className="parentPurchaseView">
                                  <div className="me-3">
                                    <strong>{t("date")}:</strong>
                                  </div>
                                  <div>{from?.date_}</div>
                                </div>
                                <div className="parentPurchaseView">
                                  <div className="me-3">
                                    <strong>
                                      {t("name")} <span>:</span>
                                    </strong>
                                  </div>
                                  <div>
                                    <p>{from?.name}</p>
                                  </div>
                                </div>
                                <div className="parentPurchaseView">
                                  <div className="me-3">
                                    <strong>
                                      {t("location")} <span>:</span>
                                    </strong>
                                  </div>
                                  <div>
                                    <p>{from?.Location}</p>
                                  </div>
                                </div>
                              </div>
                              <div className="form-group col-lg-3">
                                <div className="parentPurchaseView">
                                  <div className="me-3">
                                    <strong>
                                      {t("quantity")}
                                      <span>:</span>
                                    </strong>
                                  </div>
                                  <div>
                                    <p>{from?.Qty}</p>
                                  </div>
                                </div>
                                <div className="parentPurchaseView">
                                  <div className="me-3">
                                    <strong>
                                      {t("unit")}
                                      <span>:</span>
                                    </strong>
                                  </div>
                                  <div>
                                    <p>{from?.unit}</p>
                                  </div>
                                </div>
                                <div className="parentPurchaseView">
                                  <div className="me-3">
                                    <strong>
                                      {t("averageWeight")}
                                      <span>:</span>
                                    </strong>
                                  </div>
                                  <div>
                                    <p>{from?.average_weight}</p>
                                  </div>
                                </div>
                                <div className="parentPurchaseView">
                                  <div className="me-3">
                                    <strong>
                                      {t("crate")}
                                      <span>:</span>
                                    </strong>
                                  </div>
                                  <div>
                                    <p>{from?.Crates}</p>
                                  </div>
                                </div>
                                {/* <h6> {t("brand")} : </h6>
                                <p> {from?.brand}</p> */}
                              </div>
                              {/* <div className="form-group col-lg-3 removeBorder">
                                <h6> {t("quantity")} : </h6>
                                <p> {from?.Qty}</p>
                              </div>
                              <div className="form-group col-lg-3 removeBorder">
                                <h6>  {t("unit")} : </h6>
                                <p> {from?.unit}</p>
                              </div> */}
                            </div>
                          </div>
                          <div className="formCreate">
                            <form action="">
                              <div className="row">
                                <div className="form-group col-lg-3 ">
                                  <h6> {t("quantityUsed")}</h6>
                                  <input
                                    onChange={handleChange}
                                    type="number"
                                    name="oldqty"
                                    className="form-control"
                                    value={state.oldqty}
                                  />
                                </div>
                                <div className="form-group col-lg-3 ">
                                  <h6> {t("numberOfStaff")}</h6>
                                  <input
                                    onChange={handleChange}
                                    type="number"
                                    name="number_of_staff"
                                    className="form-control"
                                    value={state.number_of_staff}
                                  />
                                </div>
                                <div className="form-group col-lg-3 eanDateTime">
                                  <h6> {t("startTime")}</h6>
                                  <LocalizationProvider
                                    dateAdapter={AdapterDateFns}
                                  >
                                    <Box
                                      sx={{
                                        display: "flex",
                                        flexDirection: "column",
                                        alignItems: "center",
                                        mt: 4,
                                      }}
                                    >
                                      <DesktopDateTimePicker
                                        value={selectedDate1}
                                        onChange={handleDateChange1}
                                        renderInput={(params) => (
                                          <TextField {...params} />
                                        )}
                                      />
                                    </Box>
                                  </LocalizationProvider>
                                </div>
                                <div className="form-group col-lg-3 eanDateTime">
                                  <h6> {t("endTime")}</h6>

                                  <LocalizationProvider
                                    dateAdapter={AdapterDateFns}
                                  >
                                    <Box
                                      sx={{
                                        display: "flex",
                                        flexDirection: "column",
                                        alignItems: "center",
                                        mt: 4,
                                      }}
                                    >
                                      <DesktopDateTimePicker
                                        value={selectedDate}
                                        onChange={handleDateChange}
                                        renderInput={(params) => (
                                          <TextField {...params} />
                                        )}
                                      />
                                    </Box>
                                  </LocalizationProvider>
                                </div>
                              </div>
                              <div className="flex gap-2 items-center justify-between flex-wrap">
                                <div className="addBtnEan flex flex-wrap gap-3 items-center mb-4">
                                  {/* <button
                                    type="button"
                                    onClick={() => calculate()}
                                    disabled={!packingCommonId}
                                  >
                                    Calculate
                                  </button> */}
                                  <button
                                    type="button"
                                    onClick={() => calculate()}
                                  >
                                    {t("calculate")}
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => checkPackCommonId()}
                                  >
                                    {t("add")}
                                  </button>
                                </div>
                              </div>
                              <div className="table-responsive">
                                <table
                                  id="example"
                                  className="display transPortCreate table table-hover table-striped borderTerpProduce table-responsive"
                                  style={{ width: "100%" }}
                                >
                                  <thead>
                                    <tr>
                                      <th> {t("ean")}</th>
                                      <th> {t("quantity")}</th>
                                      <th> {t("unit")}</th>
                                      <th> {t("eanCost")}</th>
                                      <th> {t("averageWeight")}</th>
                                      <th> {t("eanPerKg")}</th>
                                      <th> {t("eanPerHour")}</th>
                                      <th> {t("wastage")}</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {datatable.map((item, index) => (
                                      <tr key={index}>
                                        <td>{item.ean_name_en}</td>
                                        <td>{item.ean_qty}</td>
                                        <td>{item.packing_ean_unit}</td>
                                        <td>{item.ean_cost}</td>
                                        <td>{item.average_weight}</td>
                                        <td>{item.EanPerKg}</td>
                                        <td>{item.EanPerHour}</td>
                                        <td>{item.Wastage}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <button
                        className="btn btn-danger"
                        onClick={getPackingCommonCancel}
                      >
                        {t("cancel")}
                      </button>
                      {closeButton ? (
                        <Link className="btn btn-danger" to={"/adjustEan"}>
                          {t("close")}
                        </Link>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {isOpenModal && (
          <div className="fixed inset-0 flex items-center justify-center  modalEanEdit">
            <div
              className="fixed w-screen h-screen bg-black/20"
              onClick={closeModal}
            />
            <div className="bg-white rounded-lg shadow-lg  max-w-md w-full z-50">
              <div className="crossArea">
                <h3> {t("editDetails")}</h3>
                <p onClick={closeModal}>
                  <CloseIcon />
                </p>
              </div>
              <div className="formEan formCreate">
                <div className="form-group mb-3 autoComplete">
                  <label> {t("ean")}</label>
                  {/* <ComboBox
                    options={eanListData?.map((item) => ({
                      id: item.ean_id,
                      name:
                        (email === "Plaew" && role === "Operation") ||
                          (email === "Gam" && role === "Operation") ||
                          (email === "Look Sorn" && role === "Operation")
                          ? item.ean_name_th
                          : item.ean_name_en,
                    }))}
                    value={data?.ean_id}
                    onChange={(e) => handleChangeData(e, "ean_id")}
                  /> */}

                  {/* <Autocomplete
                    disablePortal
                    options={eanListData?.map((item) => ({
                      id: item.ean_id,
                      name:
                        (email === "Plaew" && role === "Operation") ||
                        (email === "Gam" && role === "Operation") ||
                        (email === "Look Sorn" && role === "Operation")
                          ? item.ean_name_th
                          : item.ean_name_en,
                    }))}
                    getOptionLabel={(option) => option.name} // Display the name in the dropdown
                    onChange={(event, newValue) => {
                      if (newValue) {
                        handleChangeData(newValue.id, "ean_id"); // Pass the id to the handler
                      }
                    }}
                    renderInput={(params) => (
                      <TextField {...params} placeholder="Select EAN" />
                    )}
                  /> */}
                  <Autocomplete
                    disablePortal
                    options={options}
                    getOptionLabel={(option) => option.name}
                    onChange={(event, newValue) => {
                      if (newValue) {
                        handleChangeData(newValue.id, "ean_id");
                      }
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={t("selectEan")}
                        variant="outlined"
                      />
                    )}
                    value={
                      options.find((option) => option.id === data?.ean_id) ||
                      null
                    }
                    sx={{ width: 300 }}
                  />
                </div>
                <div className="form-group">
                  <label> {t("quantity")}</label>
                  <input
                    type="number"
                    value={data?.ean_quantity}
                    name="ean_quantity"
                    onChange={(e) => handleChangeQty(e)}
                  />
                </div>
                <div className="form-group mb-3 autoComplete">
                  <label> {t("unit")}</label>
                  {/* <ComboBox
                    options={unitType?.map((item) => ({
                      id: item.unit_id,
                      name: item.unit_name_en,
                    }))}
                    value={data?.unit_id}
                    onChange={(e) => handleChangeData(e, "unit_id")}
                  /> */}
                  <Autocomplete
                    disablePortal
                    options={
                      unitType
                        ? unitType?.slice(0, 3).map((item) => ({
                          id: item.ID,
                          name: item.Name_EN,
                        }))
                        : []
                    }
                    getOptionLabel={(option) => option.name || ""}
                    onChange={(event, newValue) => {
                      if (newValue) {
                        handleChangeData(newValue.id, "unit_id"); // Pass the id to the handler
                      }
                    }}
                    value={
                      unitType
                        ? unitType
                          .map((item) => ({
                            id: item.ID,
                            name: item.Name_EN,
                          }))
                          .find((item) => item.id === data?.unit_id) || null
                        : null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option.id === value.id
                    } // Compare using the same key
                    renderInput={(params) => (
                      <TextField {...params} placeholder="Select Unit" />
                    )}
                  />
                </div>
                <div className="form-group mb-3 autoComplete">
                  <label> {t("brand")}</label>
                  {/* <ComboBox
                    options={brands?.map((item) => ({
                      id: item.brand_id,
                      name: item.Brand_name,
                    }))}
                    value={data?.brand_id}
                    onChange={(e) => handleChangeData(e, "brand_id")}
                  /> */}

                  <Autocomplete
                    disablePortal
                    options={
                      brands
                        ? brands.map((item) => ({
                          id: item.ID,
                          name: item.Name_EN,
                        }))
                        : []
                    }
                    getOptionLabel={(option) => option.name || ""}
                    value={
                      brands
                        ? brands
                          .map((item) => ({
                            id: item.ID,
                            name: item.Name_EN,
                          }))
                          .find((brand) => brand.id === data?.brand_id) ||
                        null
                        : null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option.id === value.id
                    }
                    onChange={(event, newValue) => {
                      handleChangeData(
                        newValue ? newValue.id : null,
                        "brand_id"
                      );
                    }}
                    renderInput={(params) => (
                      <TextField {...params} placeholder="Select Brand" />
                    )}
                  />
                </div>

                <div className="form-group mb-3 autoComplete">
                  <label> {t("AssignedOrder")}</label>
                  {/* <select
                    value={selectedOrder}
                    onChange={(e) => setSelectedOrder(e.target.value)}
                  >
                    <option value="">Select...</option>
                    {assigned.map((item, index) => (
                      <option key={index} value={item.od_id}>
                        {item.Dropdown}
                      </option>
                    ))}
                  </select> */}
                  {/* <Autocomplete
                    disablePortal
                    options={assigned.map((item) => ({
                      id: item.od_id,
                      label: item.Dropdown,
                    }))}
                    getOptionLabel={(option) => option.label || ""}
                    value={
                      assigned
                        .map((item) => ({
                          id: item.od_id,
                          label: item.Dropdown,
                        }))
                        .find((option) => option.id === selectedOrder) || null
                    }
                    onChange={(event, newValue) => {
                      setSelectedOrder(newValue ? newValue.id : "");
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder="Select..."
                        variant="outlined"
                      />
                    )}
                  /> */}
                  <Autocomplete
                    options={[
                      { Display: "Not Allocated", OD_ID: "" },
                      ...assigned,
                    ]}
                    getOptionLabel={(option) => option.Display || ""}
                    onChange={(event, newValue) => {
                      setSelectedOrder(newValue?.OD_ID || ""); // If "Not Allocated" or null is selected, set blank
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={t("selectOrder")}
                        variant="outlined"
                      />
                    )}
                    value={
                      [
                        { Display: "Not Allocated", OD_ID: "" },
                        ...assigned,
                      ].find((option) => option.OD_ID === selectedOrder) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option.OD_ID === value.OD_ID
                    }
                    clearOnEscape
                    clearIcon={<i className="mdi mdi-close" />}
                    disablePortal
                    sx={{ width: 300 }}
                  />
                </div>
              </div>
              <div className="flex justify-center modal-footer">
                {/* <button
                    type="button"
                    className="bg-gray-300 px-4 py-2 rounded"
                    onClick={closeModal}
                  >
                    Close
                  </button> */}
                <button
                  type="button"
                  onClick={() => saveNewDetails()}
                  className="bg-black text-white px-4 py-2 rounded"
                >
                  {t("save")}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
};

export default EanRepack;
