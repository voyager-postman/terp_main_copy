import axios from "axios";
import { useEffect, useMemo, useState } from "react";
import Barcode from "react-barcode";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { TableView } from "../table";
import { Button, Modal } from "react-bootstrap";
import { useQuery } from "react-query";
import DatePicker from "react-datepicker";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import { FaCalendarAlt } from "react-icons/fa";

const CombinePayment = () => {
  const CustomInput = ({ value, onClick }) => (
    <div
      className="custom-input"
      onClick={onClick}
      style={{ display: "flex", alignItems: "center", cursor: "pointer" }}
    >
      <input
        type="text"
        value={value}
        readOnly
        style={{
          padding: "10px",
          paddingLeft: "35px",
          width: "250px",
          border: "1px solid #ccc",
          borderRadius: "5px",
        }}
      />
      <FaCalendarAlt
        style={{
          position: "absolute",
          right: "10px",
          fontSize: "18px",
          color: "#888",
        }}
      />
    </div>
  );
  const formatterTwo = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const [data, setData] = useState([]);
  const [isOn, setIsOn] = useState(true);

  const [singleDataShow, setSingleDataShow] = useState("");

  const [selectedPaymentDate, setSelectedPaymentDate] = useState(null);
  const { data: paymentChannle } = useQuery("PaymentChannela");
  const [paymentChannel, setPaymentChannel] = useState("");
  const [bankRef, setBankRef] = useState("");
  const [bankChargeAmount, setBankChargeAmount] = useState("0");
  const [depositAvailable, setDepositAvailable] = useState("");
  const [bankReference, setBankReference] = useState("");
  const [selectedPaymentChannel, setSelectedPaymentChannel] = useState("");

  const [roundingAmount, setRoundingAmount] = useState("0");
  const [totalPaymentAmount, setTotalPaymentAmount] = useState("");
  const [paymentNotes, setPaymentNotes] = useState("");
  const [payableDATA, setPayableData] = useState("");
  const [show2, setShow2] = useState(false);
  const [color, setColor] = useState(false);

  const navigate = useNavigate();
  const closeIcon2 = () => {
    setShow2(false);
    // navigate("/purchase_orders");
  };
  const newFormatter5 = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
  const handleClose2 = () => setShow2(false);
  const getCombinedPayment = () => {
    axios
      .get(`${API_BASE_URL}/getCombinedPayment`)
      .then((response) => {
        console.log(response);
        setData(response.data.data || []);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    getCombinedPayment();
  }, []);

  const updateEanStatus = (eanID) => {
    const request = {
      ean_id: eanID,
    };

    axios
      .post(`${API_BASE_URL}/eanStatus`, request)
      .then((resp) => {
        // console.log(resp, "Check Resp")
        if (resp.data.success == true) {
          toast.success("Status Updated Successfully", {
            autoClose: 1000,
            theme: "colored",
          });
          getCombinedPayment();
          return;
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const columns = useMemo(
    () => [
      {
        Header: "Cpn code",
        accessor: "CPNCODE",
      },

      {
        Header: "Vendor",
        accessor: "vendor_name",
      },

      {
        Header: "Date",
        accessor: (a) => {
          const formattedDate = new Date(a.CPN_Date).toLocaleDateString(
            "en-GB",
            {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
            }
          );

          return <div>{formattedDate}</div>;
        },
      },

      {
        Header: "Due date",
        accessor: (a) => {
          const formattedDate = new Date(a.Due_Date).toLocaleDateString(
            "en-GB",
            {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
            }
          );

          return <div>{formattedDate}</div>;
        },
      },
      {
        Header: "POs",
        accessor: (a) => <div>{a.POCount}</div>,
      },

      {
        Header: "Amount",
        accessor: (a) => (
          <div style={{ textAlign: "right" }}>
            {formatterTwo.format(a.Total_After_Tax)}
          </div>
        ),
      },

      {
        Header: "Payable",
        accessor: (a) => (
          <div style={{ textAlign: "right" }}>
            {formatterTwo.format(a.Payable)}
          </div>
        ),
      },
      // {
      //   Header: "Status",
      //   accessor: (a) => (
      //     <label
      //       style={{
      //         display: "flex",
      //         justifyContent: "center",
      //         alignItems: "center",
      //         marginTop: "10px",
      //       }}
      //       className="toggleSwitch large"
      //     >
      //       <input
      //         checked={a.Available == "1" ? true : false}
      //         onChange={() => {
      //           setIsOn(!isOn);
      //         }}
      //         onClick={() => updateEanStatus(a.ID)}
      //         value={a.Available}
      //         type="checkbox"
      //       />
      //       <span>
      //         <span>OFF</span>
      //         <span>ON</span>
      //       </span>
      //       <a></a>
      //     </label>
      //   ),
      // },

      {
        Header: "Actions",
        accessor: (a) => (
          <div className="editIcon">
            <button
              onClick={() =>
                navigate("/combinePaymentView", { state: { from: a } })
              }
            >
              <i className="mdi mdi-eye" />
            </button>
            <Link to="/combinePaymenEdit" state={{ from: a }}>
              <i className="mdi mdi-pencil pl-2" />
            </Link>

            <button type="button" onClick={() => deleteOrder(a.PO_ID)}>
              <i className="ps-2 mdi mdi-delete" />
            </button>

            {(a.Payment_Status === 1 || a.Payment_Status === 3) && (
              <button
                type="button"
                className="SvgAnchor"
                data-bs-toggle="modal"
                data-bs-target="#modalCombine"
                onClick={() => everyDataSet(a)}
              >
                <svg
                  className="SvgQuo"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                >
                  <title>cash-check</title>
                  <path d="M3 6V18H13.32C13.1 17.33 13 16.66 13 16H7C7 14.9 6.11 14 5 14V10C6.11 10 7 9.11 7 8H17C17 9.11 17.9 10 19 10V10.06C19.67 10.06 20.34 10.18 21 10.4V6H3M12 9C10.3 9.03 9 10.3 9 12C9 13.7 10.3 14.94 12 15C12.38 15 12.77 14.92 13.14 14.77C13.41 13.67 13.86 12.63 14.97 11.61C14.85 10.28 13.59 8.97 12 9M21.63 12.27L17.76 16.17L16.41 14.8L15 16.22L17.75 19L23.03 13.68L21.63 12.27Z"></path>
                </svg>
              </button>
            )}
          </div>
        ),
      },

      // {
      //   Header: "Salary",
      //   accessor: (a) => <>{"10000000"}</>,
      // },
    ],
    []
  );

  useEffect(() => {
    console.log("payableDATA:", payableDATA);
    console.log("roundingAmount:", roundingAmount);
    console.log("depositAvailable:", depositAvailable);

    setTotalPaymentAmount(
      (Number(payableDATA) || 0) +
        (Number(roundingAmount) || 0) -
        (Number(depositAvailable) || 0)
    );
  }, [payableDATA, roundingAmount, depositAvailable]);
  const everyDataSet = (a) => {
    console.log(a);

    axios
      .get(`${API_BASE_URL}/getPurchaseOrderDetails?po_id=${a?.ID}`)
      .then((response) => {
        console.log(response.data?.data1);
        setSingleDataShow(response.data?.data1);
        setPayableData(response.data?.data1?.Payable);
        setDepositAvailable(response.data?.data1?.Available_deposit);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const paymentDataClear = () => {
    setSelectedPaymentDate(null);
    setSelectedPaymentChannel("");
    setBankReference("");
    setBankChargeAmount("0");
    setDepositAvailable("");
    setRoundingAmount("");
    setTotalPaymentAmount("");
    setPaymentNotes("");
  };
  const submitPaymentData = async () => {
    if (!selectedPaymentDate) {
      setShow2(true);
      return;
    }
    if (!selectedPaymentChannel) {
      setShow2(true);
      return;
    }

    // Prepare payment data object for the first API call
    const paymentData = {
      vendor_id: singleDataShow.Vendor,
      Payment_Date: selectedPaymentDate,
      Payment_Channel: selectedPaymentChannel,
      Bank_Fees: bankChargeAmount,
      Rounding: roundingAmount,
      available_Deposit: depositAvailable,
      Payment_Amount: totalPaymentAmount,
      Notes: paymentNotes,
      Bank_Ref: bankReference,
      CPN: singleDataShow.PO_ID,
      User_id: localStorage.getItem("id"),
    };

    console.log(paymentData);

    try {
      // Send POST request to insertClientPayment endpoint (first API)
      const response = await axios.post(
        `${API_BASE_URL}/POPayments`,
        paymentData
      );
      console.log("Payment data submitted successfully", response);
      if (response?.data?.success) {
        // If success = true, show success toast
        toast.success(response.data?.message);
        let modalElement = document.getElementById("modalCombine");
        let modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) {
          modalInstance.hide();
        }
      } else {
        // If success = false, show modal with API message
        setShow1(true);
        setStock1(response.data || "Procedure returned an error");
      }
      getPurchaseOrder();
      // Update client details and summary table with collectPaymentId from the response
      const updatedCollectPaymentId = response?.data.data;
      setCollectPaymentId(updatedCollectPaymentId);

      setSelectedPaymentDate(null);
      setSelectedPaymentChannel("");
      setBankReference("");
      setBankChargeAmount("0");
      setDepositAvailable("");
      setRoundingAmount("");
      setTotalPaymentAmount("");
      setPaymentNotes("");
      // Hide modal after successful submission
    } catch (error) {
      // Handle error case for first API
      console.error("Error submitting payment data", error);
      // toast.error("Something went wrong");
    }
  };
  return (
    <>
      <Card
        title={"Combined Payment  Management"}
        endElement={
          <button
            type="button"
            onClick={() => navigate("/combinePaymenEdit")}
            className="btn button btn-info"
          >
            Create
          </button>
        }
      >
        <TableView columns={columns} data={data} />
      </Card>

      {/* paymentIcon */}
      <div
        className="modal fade "
        id="modalCombine"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modalShipTo modal-xl">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Payment
              </h1>
              <button
                type="button"
                onClick={paymentDataClear}
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <i className="mdi mdi-close"></i>
              </button>
            </div>
            <div className="modal-body">
              <div className="row">
                {/* Payment Date */}
                <div className="col-lg-6">
                  <div className="parentFormPayment">
                    <p>Payment Date</p>
                    <DatePicker
                      selected={selectedPaymentDate}
                      onChange={(date) => setSelectedPaymentDate(date)}
                      dateFormat="dd/MM/yyyy"
                      placeholderText="Click to select a date"
                      customInput={<CustomInput />}
                    />
                  </div>
                </div>

                {/* Payment Channel */}
                <div className="col-lg-6">
                  <div className="parentFormPayment autoComplete">
                    <p>Payment Channel</p>
                    <Autocomplete
                      disablePortal
                      options={paymentChannle || []}
                      value={
                        (paymentChannle || []).find(
                          (channel) =>
                            channel.bank_id === selectedPaymentChannel
                        ) || null
                      }
                      getOptionLabel={(option) => option.Bank_nick_name || ""}
                      onChange={(e, newValue) =>
                        setSelectedPaymentChannel(newValue?.bank_id || "")
                      }
                      sx={{ width: 300 }}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder="Search Payment Channel"
                          InputLabelProps={{ shrink: false }}
                        />
                      )}
                    />
                  </div>
                </div>

                {/* Bank Ref */}
                <div className="col-lg-6 mt-3">
                  <div className="parentFormPayment">
                    <p>Bank Ref</p>
                    <input
                      type="text"
                      value={bankReference}
                      onChange={(e) => setBankReference(e.target.value)}
                    />
                  </div>
                </div>

                {/* Bank Charges */}
                <div className="col-lg-6 mt-3">
                  <div className="parentFormPayment">
                    <p>Bank Charges</p>
                    <input
                      type="text"
                      value={bankChargeAmount}
                      onChange={(e) => setBankChargeAmount(e.target.value)}
                    />
                  </div>
                </div>

                {/* Available Deposit */}
                <div className="col-lg-6 mt-3">
                  <div className="parentFormPayment">
                    <p>Available Deposit</p>
                    <input
                      type="text"
                      value={depositAvailable}
                      onChange={(e) => setDepositAvailable(e.target.value)}
                    />
                  </div>
                </div>

                {/* Rounding */}
                <div className="col-lg-6 mt-3">
                  <div className="parentFormPayment">
                    <p>Rounding</p>
                    <input
                      type="text"
                      value={roundingAmount}
                      onChange={(e) => setRoundingAmount(e.target.value)}
                    />
                  </div>
                </div>

                {/* Payment Amount */}
                <div className="col-lg-6 mt-3">
                  <div className="parentFormPayment">
                    <p>Payment Amount</p>
                    {/* <input
                          type="text"
                          value={totalPaymentAmount}
                          onChange={(e) =>
                            setTotalPaymentAmount(e.target.value)
                          }
                        /> */}
                    <input
                      type="text"
                      value={newFormatter5.format(totalPaymentAmount)}
                      onChange={(e) => {
                        const rawValue = e.target.value.replace(/,/g, ""); // Remove commas
                        if (!isNaN(rawValue) && rawValue !== "") {
                          setTotalPaymentAmount(parseFloat(rawValue));
                        } else {
                          setTotalPaymentAmount("");
                        }
                      }}
                    />
                  </div>
                </div>

                {/* Notes */}
                <div className="col-lg-6 mt-3">
                  <div className="parentFormPayment">
                    <p>Notes</p>
                    <textarea
                      type="text"
                      value={paymentNotes}
                      onChange={(e) => setPaymentNotes(e.target.value)}
                    ></textarea>
                  </div>
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button
                type="button"
                onClick={submitPaymentData}
                className="btn btn-primary"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* paymentIcon end */}

      <Modal
        className="modalError receiveModal"
        show={show2}
        onHide={handleClose2}
      >
        <div className="modal-content">
          <div
            className="modal-header border-0"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          >
            <h1 className="modal-title fs-5" id="exampleModalLabel">
              Purchase Payment Check
            </h1>
            <button
              style={{ color: "#fff", fontSize: "30px" }}
              type="button"
              // onClick={() => setShow(false)}
              onClick={closeIcon2}
            >
              <i class="mdi mdi-close"></i>
            </button>
          </div>
          <div
            className="modal-body"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          >
            <div className="eanCheck errorMessage recheckReceive">
              {!selectedPaymentDate ? (
                <p style={{ backgroundColor: color ? "" : "#631f37" }}>
                  {"Payment Date is Required "}
                </p>
              ) : (
                ""
              )}

              {!selectedPaymentChannel ? (
                <p style={{ backgroundColor: color ? "" : "#631f37" }}>
                  {"Payment Channel is Required"}
                </p>
              ) : (
                ""
              )}

              <div className="closeBtnRece">
                <button onClick={closeIcon2}>Close</button>
              </div>
            </div>
          </div>
          <div
            className="modal-footer"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          ></div>
        </div>
      </Modal>
    </>
  );
};

export default CombinePayment;
