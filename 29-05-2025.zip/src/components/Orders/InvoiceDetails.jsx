const InvoiceDetails = () => {
	return <div>InvoiceDetails</div>
}

export default InvoiceDetails
