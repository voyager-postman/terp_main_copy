import axios from "axios";
import { useEffect, useMemo, useState } from "react";
import Barcode from "react-barcode";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { TableView } from "../table";

const CombinePayment = () => {
  const formatterTwo = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const [data, setData] = useState([]);
  const [isOn, setIsOn] = useState(true);
  const navigate = useNavigate();

  const getEanData = () => {
    axios
      .get(`${API_BASE_URL}/getEan`)
      .then((response) => {
        setData(response.data.data || []);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    getEanData();
  }, []);

  const updateEanStatus = (eanID) => {
    const request = {
      ean_id: eanID,
    };

    axios
      .post(`${API_BASE_URL}/eanStatus`, request)
      .then((resp) => {
        // console.log(resp, "Check Resp")
        if (resp.data.success == true) {
          toast.success("Status Updated Successfully", {
            autoClose: 1000,
            theme: "colored",
          });
          getEanData();
          return;
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const columns = useMemo(
    () => [
      {
        Header: "Cpn code",
        accessor: (a) => <div>cp-000000001</div>,
      },

      {
        Header: "Vendor",
        accessor: (a) => <div>Siam Eats</div>,
      },

      {
        Header: "Date",
        accessor: () => {
          const formattedDate = new Date("2035-03-27").toLocaleDateString(
            "en-GB",
            {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
            }
          );

          return <div>{formattedDate}</div>;
        },
      },

      {
        Header: "Due date",
        accessor: () => {
          const formattedDate = new Date("2025-03-3").toLocaleDateString(
            "en-GB",
            {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
            }
          );

          return <div>{formattedDate}</div>;
        },
      },
      {
        Header: "POs",
        accessor: (a) => <div>{a.GW}</div>,
      },

      {
        Header: "Amount",
        accessor: (a) => (
          <div style={{ textAlign: "right" }}>
            {formatterTwo.format(8700.345345)}
          </div>
        ),
      },

      {
        Header: "Payable",
        accessor: (a) => (
          <div style={{ textAlign: "right" }}>
            {formatterTwo.format(3456.345345)}
          </div>
        ),
      },
      // {
      //   Header: "Status",
      //   accessor: (a) => (
      //     <label
      //       style={{
      //         display: "flex",
      //         justifyContent: "center",
      //         alignItems: "center",
      //         marginTop: "10px",
      //       }}
      //       className="toggleSwitch large"
      //     >
      //       <input
      //         checked={a.Available == "1" ? true : false}
      //         onChange={() => {
      //           setIsOn(!isOn);
      //         }}
      //         onClick={() => updateEanStatus(a.ID)}
      //         value={a.Available}
      //         type="checkbox"
      //       />
      //       <span>
      //         <span>OFF</span>
      //         <span>ON</span>
      //       </span>
      //       <a></a>
      //     </label>
      //   ),
      // },

      {
        Header: "Actions",
        accessor: (a) => (
          <div className="editIcon">
            <button
              onClick={() =>
                navigate("/combinePaymentView", { state: { from: a } })
              }
            >
              <i className="mdi mdi-eye" />
            </button>
            <Link to="/combinePaymenEdit" state={{ from: a }}>
              <i className="mdi mdi-pencil pl-2" />
            </Link>

            <button type="button" onClick={() => deleteOrder(a.PO_ID)}>
              <i className="ps-2 mdi mdi-delete" />
            </button>

            <button
              type="button"
              className="svgIconPurchase"
              onClick={() => handleDownloadPDF(a.PO_ID, a)}
            >
              <div>
                <svg
                  version="1.0"
                  xmlns="http://www.w3.org/2000/svg"
                  width="22px"
                  height="22px"
                  viewBox="0 0 350 350"
                  preserveAspectRatio="xMidYMid meet"
                >
                  <g
                    transform="translate(0.000000,344.000000) scale(0.100000,-0.100000)"
                    fill="#203764"
                    stroke="none"
                  >
                    <path d="M1291 2913 c-19 -16 -21 -30 -23 -132 l-3 -115 -219 -37 c-270 -47 -265 -44 -249 -156 6 -43 11 -78 10 -79 -1 0 -96 -33 -212 -73 -203 -70 -245 -92 -245 -127 0 -33 274 -780 292 -796 15 -14 24 -15 39 -8 10 6 19 17 19 24 0 8 -61 184 -136 391 -74 208 -134 378 -132 380 2 1 90 32 196 68 135 47 194 63 197 54 2 -6 65 -372 140 -811 75 -440 141 -808 146 -817 5 -10 18 -20 28 -24 11 -3 167 19 346 50 180 31 332 54 338 52 5 -1 -165 -66 -378 -143 -213 -76 -391 -140 -394 -142 -4 -1 -71 179 -151 400 -79 222 -148 409 -153 416 -13 17 -42 15 -57 -3 -11 -13 13 -86 135 -428 81 -226 154 -422 161 -434 7 -12 22 -24 33 -28 12 -4 253 78 658 223 733 264 727 262 1016 262 181 0 186 1 201 22 14 20 16 118 16 859 l0 836 -175 167 -174 166 -625 0 c-579 0 -625 -1 -645 -17z m1189 -177 c0 -195 12 -206 220 -206 l130 0 0 -790 0 -790 -745 0 -745 0 -2 376 c-3 339 -5 378 -20 387 -12 8 -21 7 -32 -2 -14 -12 -16 -60 -16 -407 0 -344 2 -395 16 -408 13 -14 61 -16 367 -17 215 0 342 -4 327 -9 -32 -11 -801 -143 -806 -138 -2 2 -72 403 -155 892 -119 691 -150 889 -140 895 7 5 88 20 179 35 92 15 177 30 189 33 l23 5 2 -383 3 -384 30 0 30 0 3 513 2 512 570 0 570 0 0 -114z m260 -80 l44 -46 -112 0 -112 0 0 106 0 106 68 -60 c37 -33 87 -81 112 -106z"></path>
                    <path d="M1529 2364 c-9 -11 -10 -20 -2 -32 9 -16 58 -17 568 -17 510 0 559 1 568 17 8 12 7 21 -2 32 -12 14 -74 16 -566 16 -492 0 -554 -2 -566 -16z"></path>
                    <path d="M1536 2104 c-19 -19 -20 -36 -4 -52 17 -17 1109 -17 1126 0 18 18 14 46 -7 58 -13 6 -207 10 -560 10 -477 0 -541 -2 -555 -16z"></path>
                    <path d="M1530 1835 c-16 -19 -4 -52 23 -59 29 -8 1055 -8 1084 0 27 7 39 40 23 59 -18 22 -1112 22 -1130 0z"></path>
                    <path d="M1529 1564 c-9 -11 -10 -20 -2 -32 9 -16 60 -17 565 -20 597 -2 589 -3 573 48 -6 20 -11 20 -564 20 -497 0 -560 -2 -572 -16z"></path>
                    <path d="M1536 1304 c-9 -8 -16 -19 -16 -24 0 -5 7 -16 16 -24 14 -14 79 -16 563 -16 412 0 550 3 559 12 18 18 14 46 -7 58 -13 6 -207 10 -560 10 -477 0 -541 -2 -555 -16z"></path>
                  </g>
                </svg>
              </div>
            </button>
          </div>
        ),
      },

      // {
      //   Header: "Salary",
      //   accessor: (a) => <>{"10000000"}</>,
      // },
    ],
    []
  );

  return (
    <Card
      title={"Combined Payment  Management"}
      endElement={
        <button
          type="button"
          onClick={() => navigate("/combinePaymenEdit")}
          className="btn button btn-info"
        >
          Create
        </button>
      }
    >
      <TableView columns={columns} data={data} />
    </Card>
  );
};

export default CombinePayment;
