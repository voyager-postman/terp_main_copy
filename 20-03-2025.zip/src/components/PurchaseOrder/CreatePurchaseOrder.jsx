import axios from "axios";
import React, { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { ComboBox } from "../combobox";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import { Button, Modal } from "react-bootstrap";
import CloseIcon from "@mui/icons-material/Close";
import Select, { components } from "react-select";
import { FaCaretDown } from "react-icons/fa"; // Import an icon from react-icons

const CreatePurchaseOrder = () => {
  const [buttonClicked, setButtonClicked] = React.useState(false);
  const location = useLocation();
  const [dropdownItems, setDropdownItems] = useState([]);
  const { from } = location.state || {};
  console.log(from);
  const formatterTwo = new Intl.NumberFormat("en-US", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [stock, setStock] = useState("");
  const [color, setColor] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [details, setDetails] = React.useState([]);
  const [podId, setPodId] = useState("");
  const [tableSummary, setTableSummary] = useState("");

  const getDetils = (podId) => {
    const idToUse = podId || from?.PO_ID;
    axios
      .get(`${API_BASE_URL}/getPurchaseOrderDetails?po_id=${idToUse}`)
      .then((response) => {
        console.log(response);
        setTableSummary(response.data.data1);
        const mappedData = response.data.data.map((item) => ({
          pod_status: item.Receiving_Status,
          pod_id: item.POD_ID,
          pod_code: item.PODCODE,
          pod_type_id: item.Item,
          dropDown_id: item.Item,
          produce_name_en: item.Name_EN,
          pod_quantity: item.Qty,
          unit_count_id: item.Unit,
          Unit_Name_EN: item.Unit_Name_EN,
          Unit_Name_TH: item.Unit_Name_TH,
          item_Name_EN: item.Name_EN,
          item_Name_TH: item.Name_TH,
          pod_price: item.pod_price,
          pod_vat: item.VAT_value,
          pod_wht_id: item.WHT_value,
          pod_crate: item.Crates,
        }));
        setDetails(mappedData);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  console.log(tableSummary);
  useEffect(() => {
    getDetils();
  }, [podId, from?.PO_ID]);

  const closeIcon = () => {
    setShow(false);
    // navigate("/purchase_orders");
  };
  const handleEditDatils = (i, e) => {
    const newEditPackaging = [...details];
    newEditPackaging[i][e.target.name] = e.target.value;
    setDetails(newEditPackaging);
  };
  // const itemData1 = async () => {
  //   try {
  //     const response = await axios.post(
  //       `${API_BASE_URL}/PurchaseTypeItemsList`
  //     );
  //     setDropdownItems(response.data.data || []);
  //   } catch (error) {
  //     console.error("Error fetching purchase type items:", error);
  //   }
  // };
  // useEffect(() => {
  //   itemData1();
  // }, []);
  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const response = await axios.post(
          `${API_BASE_URL}/PurchaseTypeItemsList`
        );
        console.log(response.data);
        setOptionItem(response.data.data); // Assuming data is already an array of objects
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchOptions();
  }, []);
  useEffect(() => {
    const fetchUnits = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/getAllUnit`);
        console.log("API Response:", response.data.data);

        // Assuming response.data.data is the correct array
        setUnitItem(response.data.data || []);
      } catch (error) {
        console.error("Error fetching units:", error);
        setUnitItem([]); // Fallback to an empty array
      }
    };

    fetchUnits();
  }, []);
  const deleteDetails = async (pod_id) => {
    try {
      console.log(pod_id);

      await axios.post(`${API_BASE_URL}/deletePurchaseOrderDetails`, {
        pod_id: pod_id,
      });
      toast.success("Deleted Successfully", {
        autoClose: 1000,
        theme: "colored",
      });
      getDetils(podId);
    } catch (e) {}
  };

  const [state, setState] = React.useState({
    po_id: from?.PO_ID,
    vendor_id: from?.Vendor,
    rounding: from?.rounding,
    vendor_name: from?.Vendor_name,
    created: from?.created || "0000-00-00",
    // `${new Date().getFullYear()}-${new Date().getMonth()}${1}-${new Date().getDate()}`,
    supplier_invoice_number: from?.supplier_invoice_number,
    supplier_invoice_date: from?.supplier_invoice_date,
    supplier_dua_date: from?.supplier_dua_date,

    user_id: localStorage.getItem("id"),
  });
  console.log(state);
  const [formsValue, setFormsvalue] = React.useState({
    pod_type_id: 0,
    unit_count_id: 0,
    POD_Selection: 0,
    pod_quantity: 0,
    pod_price: 0,
    pod_vat: 0,
    pod_wht_id: 0,
    pod_crate: 0,
    Unit_Name_EN: 0,
    Unit_Name_TH: 0,
    item_Name_EN: 0,
    item_Name_TH: 0,
  });

  const addFieldHandleChange = (e) => {
    const { name, value } = e.target;
    setFormsvalue((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };
  const addFieldHandleChangeWname = (name, value) => {
    setFormsvalue((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };

  const addFormFields = () => {
    setFormsvalue((prevValues) => ({
      ...prevValues,
      pod_type_id: 0,
      unit_count_id: 0,
      POD_Selection: 0,
      pod_quantity: 0,
      pod_price: 0,
      pod_vat: 0,
      pod_wht_id: 0,
      pod_crate: 0,
      Unit_Name_EN: 0,
      Unit_Name_TH: 0,
      item_Name_EN: 0,
      item_Name_TH: 0,
    }));
  };

  const removeFormFields = (i) => {
    const newFormValues = [...formsValue];
    newFormValues.splice(i, 1);
    setFormsvalue(newFormValues);
  };

  const { data: vendorList } = useQuery("getAllVendor");
  const { data: dropdownType } = useQuery("getDropdownType");
  const { data: produceList } = useQuery("getAllProduceItem");
  const { data: packagingList } = useQuery("getAllPackaging");
  const { data: BoxList } = useQuery("getAllBoxes");
  const { data: unitType } = useQuery("getAllUnit");
  useEffect(() => {
    if (!unitType?.length) return;
    getDetils();
  }, [unitType]);
  const handleChange = (event) => {
    const { name, value } = event.target;
    setState((prevState) => {
      return {
        ...prevState,
        [name]: value,
      };
    });
  };

  const updatePurchaseOrderDetils = (id) => {
    if (!from?.PO_ID) return;
    axios
      .post(`${API_BASE_URL}/updatePurchaseOrderDetails`, {
        po_id: id,
        data: details,
      })
      .then((response) => {
        // window.location.reload(navigate("/purchase_orders"));
        navigate("/purchase_orders");
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const addPurchaseOrderDetails = async (id) => {
    try {
      const response = await axios.post(
        `${API_BASE_URL}/addPurchaseOrderDetails`,
        {
          po_id: id || from?.PO_ID,
          data: formDataAdd, // Send the object directly
          user_id: localStorage.getItem("id"),
        }
      );
      getDetils(id);
      setModalOne(false);
      console.log(response.data);
      toast.success("Successfully", {
        autoClose: 5000,
        theme: "colored",
      });
    } catch (error) {
      console.error("Error:", error);
    }
  };
  const deleteOrder = async (id) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/DeletePurchase`, {
        po_id: id,
        user_id: localStorage.getItem("id"),
      });
      console.log(response);
      // toast.success(response.data.Message_EN);
      // toast.success(response.data.Message_TH);
      navigate("/purchase_orders");
    } catch (e) {
      toast.error("Something went wrong");
      console.log(e);
    }
  };
  const update = async (e) => {
    setButtonClicked(false);
    try {
      const response = await axios.post(
        `${API_BASE_URL}/${"addPurchaseOrder"}`,
        state
      );
      console.log(response);
      setStock(response?.data);

      // 🔥 Clear the item form fields for new entry
      setFormDataAdd({
        pod_type_id: 0,
        unit_count_id: 0,
        POD_Selection: 0,
        pod_quantity: 0,
        pod_price: 0,
        pod_vat: 0,
        pod_wht_id: 0,
        pod_crate: 0,
        Unit_Name_EN: 0,
        Unit_Name_TH: 0,
        item_Name_EN: 0,
        item_Name_TH: 0,
      });

      // ✅ Keep the purchase order ID and vendor details
      setState((prevState) => ({
        ...prevState,
        po_id: response.data?.po_id || from?.po_id || prevState.po_id,
        vendor_id: prevState.vendor_id,
        created: prevState.created,
        supplier_invoice_number: prevState.supplier_invoice_number,
        supplier_invoice_date: prevState.supplier_invoice_date,
        supplier_dua_date: prevState.supplier_dua_date,

        rounding: prevState.rounding,
      }));

      if (response.status === 200) {
        if (response.data.success) {
          const id = response.data?.po_id || from?.po_id;
          console.log(id);

          setPodId(id); //  Clear podId to avoid fetching last item data
          setModalOne(true);
          // toast.success("Create Purchase Orders", {
          //   autoClose: 5000,
          //   theme: "colored",
          // });
        } else {
          setShow(true);
        }
      }
    } catch (e) {
      console.log(e);
      toast.error("An error has occurred", {
        autoClose: 5000,
        theme: "colored",
      });
    }
  };

  const updateData = async (e) => {
    try {
      const response = await axios.post(
        `${API_BASE_URL}/${"addPurchaseOrder"}`,
        state
      );
      console.log(response);
      setStock(response?.data);

      // 🔥 Clear the item form fields for new entry
      setFormDataAdd({
        pod_type_id: 0,
        unit_count_id: 0,
        POD_Selection: 0,
        pod_quantity: 0,
        pod_price: 0,
        pod_vat: 0,
        pod_wht_id: 0,
        pod_crate: 0,
        Unit_Name_EN: 0,
        Unit_Name_TH: 0,
        item_Name_EN: 0,
        item_Name_TH: 0,
      });

      // ✅ Keep the purchase order ID and vendor details
      setState((prevState) => ({
        ...prevState,
        po_id: response.data?.po_id || from?.po_id || prevState.po_id,
        vendor_id: prevState.vendor_id,
        created: prevState.created,
        supplier_invoice_number: prevState.supplier_invoice_number,
        supplier_invoice_date: prevState.supplier_invoice_date,
        rounding: prevState.rounding,
      }));

      if (response.status === 200) {
        if (response.data.success) {
          const id = response.data?.po_id || from?.po_id;
          console.log(id);

          setPodId(id);
          navigate("/purchase_orders");
          //  Clear podId to avoid fetching last item data
          // toast.success("Create Purchase Orders", {
          //   autoClose: 5000,
          //   theme: "colored",
          // });
        } else {
          setShow(true);
        }
      }
    } catch (e) {
      console.log(e);
      toast.error("An error has occurred", {
        autoClose: 5000,
        theme: "colored",
      });
    }
  };
  // console.log(details);
  // console.log(formsValue);

  // js pratima
  const [optionItem, setOptionItem] = useState([]);
  const [modalOne, setModalOne] = useState(false);
  const [unitItem, setUnitItem] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState(null);

  const [formDataAdd, setFormDataAdd] = useState({
    pod_type_id: 0,
    unit_count_id: 0,
    POD_Selection: 0,
    pod_quantity: 0,
    pod_price: 0,
    pod_vat: 0,
    pod_wht_id: 0,
    pod_crate: 0,
    Unit_Name_EN: 0,
    Unit_Name_TH: 0,
    item_Name_EN: 0,
    item_Name_TH: 0,
  });
  const handleChangeAdd = (e) => {
    const { name, value } = e.target;

    setFormDataAdd((prev) => {
      const updatedData = {
        ...prev,
        [name]: value,
      };

      // ✅ Ensure VAT updates dynamically when price, quantity, or VAT_Rate changes
      const price = parseFloat(updatedData.pod_price || 0);
      const quantity = parseFloat(updatedData.pod_quantity || 0);
      const vatRate = parseFloat(prev.VAT_Rate || 0);
      const whtRate = parseFloat(prev.WHT_Rate || 0);

      if (vatRate && price && quantity) {
        updatedData.pod_vat = ((vatRate / 100) * price * quantity).toFixed(2);
      } else {
        updatedData.pod_vat = 0;
      }

      if (whtRate && price && quantity) {
        updatedData.pod_wht_id = ((whtRate / 100) * price * quantity).toFixed(
          2
        );
      } else {
        updatedData.pod_wht_id = 0;
      }

      console.log("Updated VAT:", updatedData.pod_vat);
      console.log("Updated WHT:", updatedData.pod_wht_id);

      return updatedData;
    });
  };

  const handleVatChange = (e) => {
    const { value } = e.target;
    setFormDataAdd((prev) => ({
      ...prev,
      pod_vat: parseFloat(value) || 0, // Allow manual edit
    }));
  };
  const handleWhtChange = (e) => {
    const { value } = e.target;
    setFormDataAdd((prev) => ({
      ...prev,
      pod_wht_id: parseFloat(value) || 0, // Allow manual edit
    }));
  };

  const handleEditClick = (item) => {
    setFormDataAdd(item); // Set the selected item’s data
    setModalOne(true); // Fill the form with item data
    // Open the modal
  };

  // const handleItemChange = (event, value) => {
  //   setFormDataAdd((prev) => ({
  //     ...prev,
  //     pod_type_id: value?.ID || 0,
  //     POD_Selection: value?.ID || 0, // Save selected item ID to pod_type_id
  //   }));
  // };

  // // Handle unit dropdown change (for unit_count_id)
  // const handleUnitChange = (event, value) => {
  //   setFormDataAdd((prev) => ({
  //     ...prev,
  //     unit_count_id: value?.ID || 0, // Save selected unit ID to unit_count_id
  //   }));
  // };

  const handleItemChange = (newValue) => {
    console.log("Selected Item:", newValue);
    setFormDataAdd((prev) => {
      const updatedData = {
        ...prev,
        pod_type_id: newValue ? newValue.ID : null,
        dropDown_id: newValue ? newValue.ID : null,
        POD_Selection: newValue ? newValue.ID : null,
        item_Name_EN: newValue ? newValue.Name_EN : null,
        item_Name_TH: newValue ? newValue.Name_TH : null,
        VAT_Rate: newValue ? newValue.VAT_Rate : 0,
        WHT_Rate: newValue ? newValue.WHT_Rate : 0,
      };
      console.log("Item Selected - VAT_Rate:", updatedData.VAT_Rate);

      // Ensure VAT is calculated dynamically
      if (updatedData.VAT_Rate && prev.pod_quantity && prev.pod_price) {
        updatedData.pod_vat = (
          parseFloat(updatedData.VAT_Rate / 100) *
          parseFloat(prev.pod_quantity) *
          parseFloat(prev.pod_price)
        ).toFixed(2);
      } else {
        updatedData.pod_vat = 0; // Reset if any value is missing
      }
      if (updatedData.WHT_Rate && prev.pod_quantity && prev.pod_price) {
        updatedData.pod_wht_id = (
          parseFloat(updatedData.WHT_Rate / 100) *
          parseFloat(prev.pod_quantity) *
          parseFloat(prev.pod_price)
        ).toFixed(2);
      } else {
        updatedData.pod_wht_id = 0;
      }
      console.log("Calculated VAT:", updatedData.pod_vat);
      return updatedData;
    });
  };

  //item_Name_EN, item_Name_TH
  const handleUnitChange = (newValue) => {
    setFormDataAdd((prev) => ({
      ...prev,
      unit_count_id: newValue ? newValue.ID : null,
      Unit_Name_EN: newValue ? newValue.Name_EN : null,
      Unit_Name_TH: newValue ? newValue.Name_TH : null,
    }));
  };
  const handleCloseModalOne = () => {
    setModalOne(false); // Hide the modal
  };

  const openModalOne = () => {
    setModalOne(true); // Show the modal
  };
  const handleChangeCreate = (event) => {
    const { name, value } = event.target;
    setState((prevState) => {
      return {
        ...prevState,
        [name]: value,
      };
    });
  };

  const DropdownIndicator = (props) => {
    return (
      <components.DropdownIndicator {...props}>
        <FaCaretDown style={{ color: "black" }} />
      </components.DropdownIndicator>
    );
  };
  const customStyles = {
    control: (base) => ({
      ...base,
      borderColor: "#ccc",
      boxShadow: "none",
      "&:hover": {
        borderColor: "#888",
      },
    }),
    clearIndicator: (base) => ({
      ...base,
      opacity: "0", // Initially hide the clear button
      transition: "opacity 0.2s ease", // Smooth transition for visibility
    }),
    singleValue: (base) => ({
      ...base,
      color: "#333",
    }),
    container: (base) => ({
      ...base,
      "&:hover .react-select__clear-indicator": {
        opacity: "1", // Show the clear button on hover
      },
      "&:focus-within .react-select__clear-indicator": {
        opacity: "1", // Show the clear button on focus
      },
    }),
  };
  return (
    <>
      <Card
        title={`Purchase Order / ${from?.PO_ID ? "Update" : "Create"} Form`}
      >
        <div className="tab-content px-2 md:!px-4">
          <div className="tab-pane active" id="header" role="tabpanel">
            <div
              id="datatable_wrapper"
              className="information_dataTables dataTables_wrapper dt-bootstrap4"
            >
              <div className="formCreate">
                <form action="">
                  <div className="row cratePurchase">
                    <div className="col-lg-3 form-group parentFormPayment autoComplete">
                      <h6>Vendor</h6>
                      {/* <Autocomplete
                        options={
                          vendorList?.map((vendor) => ({
                            id: vendor.vendor_id,
                            name: vendor.name,
                          })) || []
                        } // Map vendorList to create options with `id` and `name`
                        getOptionLabel={(option) => option.name || ""} // Display the vendor name
                        value={
                          vendorList
                            ?.map((vendor) => ({
                              id: vendor.vendor_id,
                              name: vendor.name,
                            }))
                            .find((option) => option.id === state.vendor_id) ||
                          null
                        } // Match the current `vendor_id` in state with the options
                        onChange={(e, newValue) => {
                          setState({ ...state, vendor_id: newValue?.id || "" });
                          setState({
                            ...state,
                            vendor_name: newValue?.name || "",
                          });

                          // Update state with selected vendor's `id`
                        }}
                        isOptionEqualToValue={(option, value) =>
                          option.id === value.id
                        } // Ensure proper option matching
                        sx={{ width: 300 }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            placeholder="Select Vendor" // Adds a placeholder
                            InputLabelProps={{ shrink: false }} // Prevents floating label
                          />
                        )}
                      /> */}
                      <Autocomplete
                        options={
                          vendorList?.map((vendor) => ({
                            id: vendor.ID,
                            name: vendor.name,
                          })) || []
                        } // Map the vendor list to create options with `id` and `name`
                        getOptionLabel={(option) => option.name || ""} // Display the vendor name
                        value={
                          vendorList
                            ?.map((vendor) => ({
                              id: vendor.ID,
                              name: vendor.name,
                            }))
                            .find((option) => option.id === state.vendor_id) ||
                          null
                        } // Find the selected vendor by `vendor_id`
                        onChange={(e, newValue) => {
                          setState({
                            ...state,
                            vendor_id: newValue?.id || "",
                            vendor_name: newValue?.name || "",
                          }); // Update `state.vendor_id` with the selected option's `id`
                        }}
                        sx={{ width: 300 }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            placeholder="Select Vendor" // Adds a placeholder
                            InputLabelProps={{ shrink: false }} // Prevents floating label
                          />
                        )}
                      />
                    </div>
                    <div className="col-lg-2 form-group">
                      <h6>PO Date</h6>
                      <input
                        type="date"
                        name="created"
                        value={state.created}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="col-lg-3 form-group">
                      <h6>Invoice Number</h6>
                      <input
                        className="w-full"
                        type="text"
                        name="supplier_invoice_number"
                        onChange={handleChange}
                        value={state.supplier_invoice_number}
                      />
                    </div>
                    <div className="col-lg-2 form-group">
                      <h6>Invoice Date</h6>
                      <input
                        type="date"
                        name="supplier_invoice_date"
                        value={state.supplier_invoice_date}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="col-lg-2 form-group">
                      <h6>Due Date</h6>
                      <input
                        type="date"
                        name="supplier_dua_date"
                        value={state.supplier_dua_date}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  <div className="addButton">
                    {/* Button trigger modal */}
                    <button
                      type="button"
                      className="btn btn-primary"
                      // onClick={openModalOne}
                      onClick={update}
                    >
                      Add
                    </button>
                    {modalOne && (
                      <div
                        className="fixed inset-0 flex items-center justify-center"
                        style={{ zIndex: "9999" }}
                      >
                        <div
                          className="fixed w-screen h-screen bg-black/20"
                          onClick={handleCloseModalOne}
                        />
                        <div className="bg-white rounded-lg shadow-lg max-w-md w-full ">
                          <div className="crossArea">
                            <h3>Edit Details</h3>
                            <p onClick={handleCloseModalOne}>
                              <CloseIcon />
                            </p>
                          </div>
                          <div className="formEan formCreate">
                            <div className="modal-body modalShipTo p-0 ">
                              {/* <h1>hello</h1> */}

                              <div className="addMOdalContent formCreate mt-0 px-2">
                                <div className="col-lg-12 autoComplete mb-2 ">
                                  <h6>Select Item</h6>
                                  {/* <Autocomplete
                                    disablePortal
                                    options={
                                      Array.isArray(optionItem)
                                        ? optionItem
                                        : []
                                    }
                                    getOptionLabel={(option) =>
                                      option.Name_EN || option.Name_TH || ""
                                    }
                                    value={
                                      optionItem.find(
                                        (opt) =>
                                          opt.ID === formDataAdd.pod_type_id
                                      ) || null
                                    } // Set value
                                    onChange={(e, newValue) =>
                                      handleItemChange(newValue)
                                    }
                                    renderInput={(params) => (
                                      <TextField
                                        {...params}
                                        placeholder="Select Item"
                                      />
                                    )}
                                  /> */}
                                  <Select
                                    value={
                                      optionItem.find(
                                        (opt) =>
                                          opt.ID === formDataAdd.pod_type_id
                                      ) || null
                                    } // The selected value (set to null if no match)
                                    onChange={(selectedOption) =>
                                      handleItemChange(selectedOption)
                                    } // Handle selection
                                    options={optionItem || []} // The dropdown options
                                    getOptionLabel={(option) =>
                                      option.Name_EN || option.Name_TH || ""
                                    }
                                    getOptionValue={(option) => option.ID} // Ensure correct ID selection
                                    placeholder="Select Item"
                                    isClearable // Adds a clear button
                                    styles={customStyles}
                                    classNamePrefix="react-select" // Add a prefix for CSS class names
                                  />
                                </div>
                                <div className="col-lg-12 autoComplete mb-2">
                                  <h6>Unit</h6>
                                  <Autocomplete
                                    disablePortal
                                    options={
                                      Array.isArray(unitItem) ? unitItem : []
                                    }
                                    getOptionLabel={(option) =>
                                      option.Name_EN ||
                                      option.Name_TH ||
                                      "Unknown Unit"
                                    }
                                    value={
                                      unitItem.find(
                                        (opt) =>
                                          opt.ID === formDataAdd.unit_count_id
                                      ) || null
                                    } // Set value
                                    onChange={(e, newValue) =>
                                      handleUnitChange(newValue)
                                    }
                                    renderInput={(params) => (
                                      <TextField
                                        {...params}
                                        placeholder="Unit"
                                      />
                                    )}
                                  />
                                </div>
                                <div className="col-lg-12 mb-2">
                                  <h6>Quantity</h6>
                                  <input
                                    className="mb-0"
                                    type="text"
                                    name="pod_quantity"
                                    value={formDataAdd.pod_quantity || ""}
                                    placeholder="Quantity"
                                    onChange={handleChangeAdd}
                                  />
                                </div>
                                <div className="col-lg-12 mb-2">
                                  <h6>Crate</h6>
                                  <input
                                    className="mb-0"
                                    type="text"
                                    name="pod_crate"
                                    value={formDataAdd.pod_crate}
                                    placeholder="Crate"
                                    onChange={handleChangeAdd}
                                  />
                                </div>

                                <div className="col-lg-12 mb-2">
                                  <h6>Price</h6>
                                  <input
                                    className="mb-0"
                                    type="number"
                                    name="pod_price"
                                    value={formDataAdd.pod_price}
                                    placeholder="Price"
                                    onChange={handleChangeAdd}
                                  />
                                </div>

                                <div className="row mb-2">
                                  <div className="col-lg-6">
                                    <h6>VAT</h6>
                                    <input
                                      className="mb-0"
                                      type="number"
                                      name="pod_vat"
                                      value={formDataAdd.pod_vat}
                                      placeholder="VAT"
                                      onChange={handleVatChange}
                                    />
                                  </div>

                                  <div className="col-lg-6">
                                    <h6>WHT</h6>
                                    <input
                                      className="mb-0"
                                      type="number"
                                      name="pod_wht_id"
                                      value={formDataAdd.pod_wht_id}
                                      placeholder="WHT"
                                      onChange={handleWhtChange} // Handle manual edits
                                    />
                                  </div>
                                </div>

                                {/* <div className="row">
                                  <div className="col-lg-12 mb-2">
                                    <h6>Total</h6>
                                    <input
                                      className="mb-0"
                                      type="number"
                                      name="total"
                                      value={formDataAdd.total}
                                      placeholder="Total"
                                      onChange={handleChangeAdd}
                                    />
                                  </div>
                                </div> */}
                                <div className="row">
                                  <div className="col-lg-12 mb-2">
                                    <h6>Total</h6>
                                    <input
                                      className="mb-0 border-0"
                                      type="number"
                                      name="total"
                                      placeholder="Total"
                                      value={
                                        formDataAdd.pod_price &&
                                        formDataAdd.pod_quantity
                                          ? (
                                              parseFloat(
                                                formDataAdd.pod_price || 0
                                              ) *
                                                parseFloat(
                                                  formDataAdd.pod_quantity || 0
                                                ) + // price * quantity
                                              parseFloat(
                                                formDataAdd.pod_vat || 0
                                              ) - // Add VAT value
                                              parseFloat(
                                                formDataAdd.pod_wht_id || 0
                                              )
                                            ).toFixed(2) // Fix to 2 decimal places
                                          : 0 // Show 0 if price or quantity is missing
                                      }
                                      disabled={+formDataAdd.pod_status !== 1}
                                      readOnly
                                    />
                                  </div>
                                </div>

                                <button
                                  type="button"
                                  className="UpdatePopupBtn btn btn-primary m-0"
                                  onClick={() => addPurchaseOrderDetails(podId)}
                                >
                                  Add
                                </button>
                              </div>
                            </div>
                          </div>
                          <div className="modal-footer"></div>
                        </div>
                      </div>
                    )}
                  </div>
                  {/* table new */}

                  <div
                    id="datatable_wrapper"
                    className="information_dataTables dataTables_wrapper dt-bootstrap4 table-responsive mt-"
                  >
                    <table
                      id="example"
                      className=" tableLr display transPortCreate table table-hover table-striped borderTerpProduce table-responsive purchaseCreateTable"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          <th style={{ width: "170px" }}>Pod Code</th>
                          {/* <th style={{ width: "250px" }}>Type</th> */}
                          <th style={{ width: "350px" }}>Item</th>
                          <th style={{ width: "150px" }}>Quantity</th>
                          <th style={{ width: "100px" }}>Unit</th>
                          <th style={{ width: "150px" }}>Price</th>
                          <th style={{ width: "70px" }}>VAT</th>
                          <th style={{ width: "150px" }}>Total</th>
                          <th style={{ width: "100px" }}>WHT</th>
                          <th style={{ width: "100px" }}>Crate</th>
                          <th style={{ width: "100px" }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {details.map((item, index) => (
                          <tr key={index}>
                            <td className="text-center">{item.pod_code}</td>
                            <td>{item.produce_name_en}</td>
                            <td className="text-right">
                              {formatterTwo.format(item.pod_quantity)}
                            </td>
                            <td className="text-center">{item.Unit_Name_EN}</td>
                            <td className="text-right">
                              {" "}
                              {formatterTwo.format(item.pod_price)}
                            </td>
                            <td className="text-right">
                              {formatterTwo.format(item.pod_vat)}
                            </td>
                            <td className="text-right">
                              {formatterTwo.format(
                                item.pod_quantity * item.pod_price
                              )}
                            </td>
                            <td className="text-right">
                              {formatterTwo.format(item.pod_wht_id)}
                            </td>
                            <td className="text-right">
                              {formatterTwo.format(item.pod_crate)}
                            </td>
                            <td>
                              <button
                                type="button"
                                onClick={() => handleEditClick(item)}
                              >
                                <i className="mdi mdi-pencil text-2xl" />
                              </button>
                              <button
                                type="button"
                                onClick={() => deleteDetails(item.pod_id)}
                              >
                                <i className="mdi mdi-minus text-2xl" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>

                      {/* <tbody>
                              {details?.map((v, i) => (
                                <tr key={`b_${i}`} className="rowCursorPointer">
                                  <td className="borderUnsetPod">
                                    {v.pod_status == "1" ? (
                                      <input
                                        className="border-0"
                                        value={v.pod_code}
                                      />
                                    ) : (
                                      <>{v.pod_code}</>
                                    )}
                                  </td>

                                  <td className="autoFull">
                                    {v.pod_status == "1" ? (
                                      <Autocomplete
                                        className="unsetPurchaseWidth"
                                        value={
                                          dropdownItems?.find(
                                            (item) => item.ID === v.dropDown_id
                                          ) || null
                                        }
                                        options={dropdownItems}
                                        getOptionLabel={(option) =>
                                          option.produce_name_en || ""
                                        }
                                        onChange={(event, newValue) => {
                                          if (+v.pod_status !== 1) return;
                                          const newEditPackaging = [...details];
                                          newEditPackaging[i].dropDown_id =
                                            newValue?.ID || null;
                                          setDetails(newEditPackaging);
                                        }}
                                        renderInput={(params) => (
                                          <TextField
                                            {...params}
                                            variant="outlined"
                                            placeholder="Select Item"
                                            // label="Select Produce"
                                          />
                                        )}
                                      />
                                    ) : (
                                      <> {v.produce_name_en} </>
                                    )}
                                  </td>

                                  <td clas>
                                    {v.pod_status == "1" ? (
                                      <input
                                        className="border-0"
                                        type="text"
                                        name="pod_quantity"
                                        disabled={+v.pod_status != 1}
                                        value={v.pod_quantity}
                                        onChange={(e) => handleEditDatils(i, e)}
                                      />
                                    ) : (
                                      <> {v.pod_quantity}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <Autocomplete
                                        options={unitType}
                                        value={
                                          unitType?.find(
                                            (item) =>
                                              item.unit_id === v.unit_count_id
                                          ) || null
                                        }
                                        getOptionLabel={(option) =>
                                          option.unit_name_en || ""
                                        }
                                        onChange={(event, newValue) => {
                                          if (+v.pod_status !== 1) return;
                                          const newEditPackaging = [...details];
                                          newEditPackaging[i].unit_count_id =
                                            newValue?.unit_id || null;
                                          setDetails(newEditPackaging);
                                        }}
                                        renderInput={(params) => (
                                          <TextField
                                            {...params}
                                            variant="outlined"
                                            placeholder="Select Unit"
                                            // label="Select Unit"
                                          />
                                        )}
                                      />
                                    ) : (
                                      // <ComboBox
                                      //   options={unitType?.map((v) => ({
                                      //     id: v.unit_id,
                                      //     name: v.unit_name_en,
                                      //   }))}
                                      //   value={v.unit_count_id}
                                      //   onChange={(e) => {
                                      //     if (+v.pod_status != 1) return;
                                      //     const newEditPackaging = [...details];
                                      //     newEditPackaging[i].unit_count_id = e;
                                      //     setDetails(newEditPackaging);
                                      //   }}
                                      // />
                                      <> {v.unit_count_id}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="number"
                                        name="pod_price"
                                        className="border-0"
                                        defaultValue={v.pod_price}
                                        disabled={+v.pod_status != 1}
                                        onChange={(e) => handleEditDatils(i, e)}
                                      />
                                    ) : (
                                      <> {v.pod_price}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="number"
                                        name="pod_vat"
                                        className="border-0"
                                        defaultValue={v.pod_vat}
                                        disabled={+v.pod_status != 1}
                                        onChange={(e) => handleEditDatils(i, e)}
                                        style={{ width: "50px" }}
                                      />
                                    ) : (
                                      <> {v.pod_vat}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="text"
                                        readOnly
                                        className="border-0"
                                        disabled={+v.pod_status != 1}
                                        value={(
                                          +(
                                            +v.pod_price *
                                            +v.pod_quantity *
                                            (v.pod_vat / 100)
                                          ) +
                                          +v.pod_price * +v.pod_quantity
                                        ).toLocaleString("en-us")}
                                      />
                                    ) : (
                                      <>
                                        {" "}
                                        {(
                                          +(
                                            +v.pod_price *
                                            +v.pod_quantity *
                                            (v.pod_vat / 100)
                                          ) +
                                          +v.pod_price * +v.pod_quantity
                                        ).toLocaleString("en-us")}
                                      </>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="text"
                                        name="pod_wht_id"
                                        className="border-0"
                                        disabled={+v.pod_status != 1}
                                        style={{ width: "50px" }}
                                        value={v.pod_wht_id}
                                        onChange={(e) => handleEditDatils(i, e)}
                                      />
                                    ) : (
                                      <> {v.pod_wht_id}</>
                                    )}
                                  </td>
                                  <td>
                                    {v.pod_status == "1" ? (
                                      <input
                                        type="text"
                                        name="pod_crate"
                                        className="border-0"
                                        style={{ width: "70px" }}
                                        disabled={+v.pod_status != 1}
                                        value={v.pod_crate}
                                        onChange={(e) => handleEditDatils(i, e)}
                                      />
                                    ) : (
                                      <> {v.pod_crate}</>
                                    )}
                                  </td>
                                  <td className="editIcon">
                                    {+v.pod_status == 1 ? (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const i = window.confirm(
                                            "Do you want to delete this Order details?"
                                          );
                                          if (i) {
                                            deleteDetails(v.pod_id);
                                          }
                                        }}
                                      >
                                        <i className="mdi mdi-trash-can-outline" />
                                      </button>
                                    ) : (
                                      <> </>
                                    )}
                                  </td>
                                </tr>
                              ))}
                              {formsValue?.map((element, index) => (
                                <tr
                                  key={`a_${index}`}
                                  className="rowCursorPointer"
                                >
                                  <td> </td>
                                  <td>
                                    <Autocomplete
                                      value={
                                        dropdownItems?.find(
                                          (item) =>
                                            item.ID === element.POD_Selection
                                        ) || null
                                      }
                                      options={dropdownItems}
                                      getOptionLabel={(option) =>
                                        option.Name_EN || ""
                                      }
                                      onChange={(event, newValue) =>
                                        addFieldHandleChangeWname(
                                          index,
                                          "POD_Selection",
                                          newValue?.ID || null
                                        )
                                      }
                                      renderInput={(params) => (
                                        <TextField
                                          {...params}
                                          placeholder="Select Item"
                                          variant="outlined"
                                          // label="Select POD"
                                        />
                                      )}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name="pod_quantity"
                                      className="border-0"
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_quantity}
                                    />
                                  </td>
                                  <td>
                                    <Autocomplete
                                      value={
                                        unitType?.find(
                                          (item) =>
                                            item.ID === element.unit_count_id
                                        ) || null
                                      }
                                      options={unitType}
                                      getOptionLabel={(option) =>
                                        option.Name_EN || ""
                                      }
                                      onChange={(event, newValue) =>
                                        addFieldHandleChangeWname(
                                          index,
                                          "unit_count_id",
                                          newValue?.ID || null
                                        )
                                      }
                                      renderInput={(params) => (
                                        <TextField
                                          {...params}
                                          variant="outlined"
                                          placeholder="Select Unit"
                                        />
                                      )}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="number"
                                      name="pod_price"
                                      className="border-0"
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_price}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="number"
                                      name="pod_vat"
                                      className="border-0"
                                      style={{ width: "50px" }}
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_vat}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      readOnly
                                      className="border-0"
                                      value={(
                                        +(
                                          +element.pod_price *
                                          +element.pod_quantity *
                                          (element.pod_vat / 100)
                                        ) +
                                        +element.pod_price *
                                          +element.pod_quantity
                                      ).toLocaleString("en-us")}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name="pod_wht_id"
                                      style={{ width: "50px" }}
                                      className="border-0"
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_wht_id}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name="pod_crate"
                                      className="border-0"
                                      style={{ width: "70px" }}
                                      onChange={(e) =>
                                        addFieldHandleChange(index, e)
                                      }
                                      defaultValue={element.pod_crate}
                                    />
                                  </td>
                                  <td>
                                    {index == formsValue.length - 1 ? (
                                      <button
                                        type="button"
                                        onClick={addFormFields}
                                        className="cursor-pointer"
                                      >
                                        <i className="mdi mdi-plus text-xl" />
                                      </button>
                                    ) : (
                                      <button
                                        type="button"
                                        className="cursor-pointer"
                                        onClick={() => removeFormFields(index)}
                                      >
                                        <i className="mdi mdi-trash-can-outline text-xl" />
                                      </button>
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody> */}
                    </table>
                  </div>
                  {/* table new end */}
                  <div className="flex justify-content-end mt-4 totalBefore">
                    <div>
                      <div className="flexBefore">
                        <div>
                          <strong>Total Before Tax : </strong>
                        </div>
                        <div>
                          <span>
                            {formatterTwo.format(
                              tableSummary?.Total_Before_Tax ?? 0
                            )}
                          </span>
                        </div>
                      </div>
                      <div className="flexBefore">
                        <div>
                          <strong>VAT : </strong>
                        </div>
                        <div>
                          <span>
                            {formatterTwo.format(tableSummary?.VAT ?? 0)}
                          </span>
                        </div>
                      </div>
                      <div className="flexBefore">
                        <div>
                          <strong>WHT : </strong>
                        </div>
                        <div>
                          <span>
                            {formatterTwo.format(tableSummary?.WHT ?? 0)}
                          </span>
                        </div>
                      </div>
                      <div className=" d-flex flexBefore">
                        <div>
                          <strong>Rounding</strong>
                        </div>
                        <input
                          type="number"
                          name="rounding"
                          value={state.rounding}
                          onChange={(e) =>
                            handleChange({
                              target: {
                                name: "rounding",
                                value: parseFloat(e.target.value) || 0,
                              },
                            })
                          }
                        />
                      </div>
                      <div className="flexBefore">
                        <div>
                          <strong>Amount to Pay : </strong>
                        </div>
                        <div>
                          <span>
                            {formatterTwo.format(
                              (tableSummary?.Total_Before_Tax ?? 0) +
                                (tableSummary?.VAT ?? 0) +
                                (tableSummary?.WHT ?? 0) +
                                (state.rounding ?? 0)
                            )}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* <div
                    id="datatable_wrapper"
                    className="information_dataTables dataTables_wrapper dt-bootstrap4 table-responsive mt-"
                  >
                    <table
                      id="example"
                      className="display transPortCreate table table-hover table-striped borderTerpProduce table-responsive purchaseCreateTable"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          <th style={{ width: "170px" }}>Pod Code</th>
                         
                          <th style={{ width: "350px" }}>Item</th>
                          <th style={{ width: "150px" }}>Quantity</th>
                          <th style={{ width: "100px" }}>Unit</th>
                          <th style={{ width: "150px" }}>Price</th>
                          <th style={{ width: "70px" }}>VAT</th>
                          <th style={{ width: "150px" }}>Total</th>
                          <th style={{ width: "100px" }}>WHT</th>
                          <th style={{ width: "100px" }}>Crate</th>
                          <th style={{ width: "100px" }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {details?.map((v, i) => (
                          <tr key={`b_${i}`} className="rowCursorPointer">
                            <td className="borderUnsetPod">
                              {v.pod_status == "1" ? (
                                <input
                                  className="border-0"
                                  value={v.pod_code}
                                />
                              ) : (
                                <>{v.pod_code}</>
                              )}
                            </td>

                            <td>
                              {v.pod_status == "1" ? (
                                <Autocomplete
                                  className="unsetPurchaseWidth"
                                  value={
                                    dropdownItems?.find(
                                      (item) => item.ID === v.dropDown_id
                                    ) || null
                                  }
                                  options={dropdownItems}
                                  getOptionLabel={(option) =>
                                    option.Name_EN || ""
                                  }
                                  onChange={(event, newValue) => {
                                    if (+v.pod_status !== 1) return;
                                    const newEditPackaging = [...details];
                                    newEditPackaging[i].dropDown_id =
                                      newValue?.ID || null;
                                    setDetails(newEditPackaging);
                                  }}
                                  renderInput={(params) => (
                                    <TextField
                                      {...params}
                                      variant="outlined"
                                      placeholder="Select Item"
                                  
                                    />
                                  )}
                                />
                              ) : (
                                <> {v.produce_name_en} </>
                              )}
                            </td>

                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  className="border-0"
                                  type="text"
                                  name="pod_quantity"
                                  disabled={+v.pod_status != 1}
                                  value={v.pod_quantity}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_quantity}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <Autocomplete
                                  options={unitType}
                                  value={
                                    unitType?.find(
                                      (item) => item.ID === v.unit_count_id
                                    ) || null
                                  }
                                  getOptionLabel={(option) =>
                                    option.Name_EN || ""
                                  }
                                  onChange={(event, newValue) => {
                                    if (+v.pod_status !== 1) return;
                                    const newEditPackaging = [...details];
                                    newEditPackaging[i].unit_count_id =
                                      newValue?.ID || null;
                                    setDetails(newEditPackaging);
                                  }}
                                  renderInput={(params) => (
                                    <TextField
                                      {...params}
                                      variant="outlined"
                                      placeholder="Select Unit"
                                    
                                    />
                                  )}
                                />
                              ) : (
                                <> {v.unit_count_id}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="number"
                                  name="pod_price"
                                  className="border-0"
                                  defaultValue={v.pod_price}
                                  disabled={+v.pod_status != 1}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_price}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="number"
                                  name="pod_vat"
                                  className="border-0"
                                  defaultValue={v.pod_vat}
                                  disabled={+v.pod_status != 1}
                                  onChange={(e) => handleEditDatils(i, e)}
                                  style={{ width: "50px" }}
                                />
                              ) : (
                                <> {v.pod_vat}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  readOnly
                                  className="border-0"
                                  disabled={+v.pod_status != 1}
                                  value={(
                                    +(
                                      +v.pod_price *
                                      +v.pod_quantity *
                                      (v.pod_vat / 100)
                                    ) +
                                    +v.pod_price * +v.pod_quantity
                                  ).toLocaleString("en-us")}
                                />
                              ) : (
                                <>
                                  {" "}
                                  {(
                                    +(
                                      +v.pod_price *
                                      +v.pod_quantity *
                                      (v.pod_vat / 100)
                                    ) +
                                    +v.pod_price * +v.pod_quantity
                                  ).toLocaleString("en-us")}
                                </>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  name="pod_wht_id"
                                  className="border-0"
                                  disabled={+v.pod_status != 1}
                                  style={{ width: "50px" }}
                                  value={v.pod_wht_id}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_wht_id}</>
                              )}
                            </td>
                            <td>
                              {v.pod_status == "1" ? (
                                <input
                                  type="text"
                                  name="pod_crate"
                                  className="border-0"
                                  style={{ width: "70px" }}
                                  disabled={+v.pod_status != 1}
                                  value={v.pod_crate}
                                  onChange={(e) => handleEditDatils(i, e)}
                                />
                              ) : (
                                <> {v.pod_crate}</>
                              )}
                            </td>
                            <td className="editIcon">
                              {+v.pod_status == 1 ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const i = window.confirm(
                                      "Do you want to delete this Order details?"
                                    );
                                    if (i) {
                                      deleteDetails(v.pod_id);
                                    }
                                  }}
                                >
                                  <i className="mdi mdi-trash-can-outline" />
                                </button>
                              ) : (
                                <> </>
                              )}
                            </td>
                          </tr>
                        ))}
                        {formsValue?.map((element, index) => (
                          <tr
                            key={`a_${index}`}
                            className="rowCursorPointer"
                            data-bs-toggle="modal"
                            data-bs-target="#myModal"
                          >
                            <td> </td>

                            <td>
                              <Autocomplete
                                value={
                                  dropdownItems?.find(
                                    (item) => item.ID === element.POD_Selection
                                  ) || null
                                }
                                options={dropdownItems}
                                getOptionLabel={(option) =>
                                  option.Name_EN || ""
                                }
                                onChange={(event, newValue) =>
                                  addFieldHandleChangeWname(
                                    index,
                                    "POD_Selection",
                                    newValue?.ID || null
                                  )
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    placeholder="Select Item"
                                    variant="outlined"
                                  
                                  />
                                )}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_quantity"
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_quantity}
                              />
                            </td>
                            <td>
                              <Autocomplete
                                value={
                                  unitType?.find(
                                    (item) => item.ID === element.unit_count_id
                                  ) || null
                                }
                                options={unitType}
                                getOptionLabel={(option) =>
                                  option.Name_EN || ""
                                }
                                onChange={(event, newValue) =>
                                  addFieldHandleChangeWname(
                                    index,
                                    "unit_count_id",
                                    newValue?.ID || null
                                  )
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    variant="outlined"
                                    placeholder="Select Unit"
                                  />
                                )}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                name="pod_price"
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_price}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                name="pod_vat"
                                className="border-0"
                                style={{ width: "50px" }}
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_vat}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                readOnly
                                className="border-0"
                                value={(
                                  +(
                                    +element.pod_price *
                                    +element.pod_quantity *
                                    (element.pod_vat / 100)
                                  ) +
                                  +element.pod_price * +element.pod_quantity
                                ).toLocaleString("en-us")}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_wht_id"
                                style={{ width: "50px" }}
                                className="border-0"
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_wht_id}
                              />
                            </td>
                            <td>
                              <input
                                type="text"
                                name="pod_crate"
                                className="border-0"
                                style={{ width: "70px" }}
                                onChange={(e) => addFieldHandleChange(index, e)}
                                defaultValue={element.pod_crate}
                              />
                            </td>
                            <td>
                              {index == formsValue.length - 1 ? (
                                <button
                                  type="button"
                                  onClick={addFormFields}
                                  className="cursor-pointer"
                                >
                                  <i className="mdi mdi-plus text-xl" />
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  className="cursor-pointer"
                                  onClick={() => removeFormFields(index)}
                                >
                                  <i className="mdi mdi-trash-can-outline text-xl" />
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div> */}
                </form>
              </div>
            </div>
          </div>
          <div className="card-footer">
            <button
              className="btn btn-primary"
              type="submit"
              name="signup"
              onClick={updateData}
              disabled={buttonClicked}
            >
              {from?.PO_ID ? "Update" : "Create"}
            </button>
            <Link
              className="btn btn-danger"
              to={from?.PO_ID ? "/purchase_orders" : "/purchase_orders"} // Redirect if PO_ID exists
              onClick={(e) => {
                if (!podId) return; // Do nothing if podId is missing
                e.preventDefault(); // Prevent navigation if deleting
                deleteOrder(podId); // Call delete function
              }}
            >
              Cancel
            </Link>
          </div>
        </div>
      </Card>

      <Modal
        className="modalError receiveModal"
        show={show}
        onHide={handleClose}
      >
        <div className="modal-content">
          <div
            className="modal-header border-0"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          >
            <h1 className="modal-title fs-5" id="exampleModalLabel">
              Purchase Order Check
            </h1>
            <button
              style={{ color: "#fff", fontSize: "30px" }}
              type="button"
              // onClick={() => setShow(false)}
              onClick={closeIcon}
            >
              <i class="mdi mdi-close"></i>
            </button>
          </div>
          <div
            className="modal-body"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          >
            <div className="eanCheck errorMessage recheckReceive">
              <p style={{ backgroundColor: color ? "" : "#631f37" }}>
                {stock.message_en ? stock.message_en : "NULL"}
              </p>
              <p style={{ backgroundColor: color ? "" : "#631f37" }}>
                {stock.message_th ? stock.message_th : "NULL"}
              </p>
              <div className="closeBtnRece">
                <button onClick={closeIcon}>Close</button>
              </div>
            </div>
          </div>
          <div
            className="modal-footer"
            style={{ backgroundColor: color ? "#2f423c" : "" }}
          ></div>
        </div>
      </Modal>
    </>
  );
};

export default CreatePurchaseOrder;
