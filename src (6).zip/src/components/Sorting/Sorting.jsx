import axios from "axios";
import React, { useMemo, useState, useEffect } from "react";
import { useQuery } from "react-query";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { TableView } from "../table";

const Sorting = () => {
  const { data: sorted, refetch } = useQuery("getSorting");
  const [data, setData] = useState([]);
  const [restoredRows, setRestoredRows] = useState([]);
  console.log(sorted);
  const getSortData = () => {
    axios.get(`${API_BASE_URL}/getViewToSort`).then((res) => {
      console.log(res);
      setData(res.data.data || []);
    });
  };

  useEffect(() => {
    getSortData();
  }, []);
  const formatTwoDecimals = (value) => {
    return new Intl.NumberFormat(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value); // <-- .format moved here inside the function
  };
  const restoreSorting = (id, id1) => {
    if (restoredRows.includes(id)) {
      return; // Do nothing if already restored
    }

    axios
      .post(`${API_BASE_URL}/restoreSorting`, {
        receiving_id: id,
        user_id: localStorage.getItem("id"),
        pod_code: id1,
      })
      .then((response) => {
        if (response?.data?.success == false) {
          toast.warn(response.data.message, {
            autoClose: 1000,
            theme: "colored",
          });
          getSortData();
        }
        console.log(response);
        if (response?.data?.success == true) {
          toast.success(response.data.message, {
            autoClose: 1000,
            theme: "colored",
          });
          getSortData();
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const columns = useMemo(
    () => [
      {
        Header: () => <div style={{ textAlign: "center" }}>PO CODE</div>,
        accessor: "PODCODE",
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Vender Name</div>,
        accessor: "Vendor_Name",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        // if your table supports it
      },
      {
        Header: () => <div style={{ textAlign: "center" }}> Name</div>,

        accessor: "Name_EN",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        headerStyle: { textAlign: "left" },
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Date</div>,
        accessor: (row) => {
          const date = new Date(row.Date);
          return date.toLocaleDateString("en-GB"); // 'en-GB' gives dd/mm/yyyy format
        },
        id: "Date", // important when using function accessor
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Crates</div>,
        accessor: "Crates",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>
            {formatTwoDecimals(value)}{" "}
            {/* <-- correctly calling the function */}
          </div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Quantity</div>,
        accessor: "Quantity",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Unit</div>,
        accessor: "Unit",
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Cost</div>,
        accessor: "Cost",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>QTY / Crate</div>,

        accessor: "Qty/Crate",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Status</div>,

        accessor: "Status",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        headerStyle: { textAlign: "left" },
      },

      {
        Header: "Actions",
        accessor: (a) => (
          <>
            <Link state={{ from: a }} to="/newSorting">
              <i
                className="mdi mdi-check"
                style={{
                  width: "20px",
                  color: "#203764",
                  fontSize: "22px",
                  marginTop: "10px",
                }}
              />
            </Link>
            <button
              type="button"
              onClick={() => restoreSorting(a.receiving_id, a.pod_code)}
              disabled={restoredRows.includes(a.receiving_id)}
            >
              <i
                className="mdi mdi-restore"
                style={{
                  width: "20px",
                  color: "#203764",
                  fontSize: "22px",
                  marginTop: "10px",
                }}
              />
            </button>
          </>
        ),
      },
    ],
    [restoredRows]
  );

  return (
    <Card title="Sorting Management">
      <TableView columns={columns} data={data || []} />
    </Card>
  );
};

export default Sorting;
