import React from "react";
import { useQuery } from "react-query";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import { API_BASE_URL } from "../../Url/Url";
import { Card } from "../../card";
import { TableView } from "../table";
import { toast } from "react-toastify";
import { Button, Modal } from "react-bootstrap";

const Receiving = () => {
  const navigate = useNavigate();
  const formatTwoDecimals = (value) => {
    return new Intl.NumberFormat(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value); // <-- .format moved here inside the function
  };
  const [data, setData] = useState([]);
  const [dataSet, setDataSet] = useState("");
  const getReceiving = () => {
    axios.get(`${API_BASE_URL}/getViewToReceving`).then((res) => {
      setData(res.data.data || []);
    });
  };
  useEffect(() => {
    getReceiving();
  }, []);
  // const { data } = useQuery("getViewToReceving");
  console.log(data);
  const handleDownloadPDF = async (PODCODE, Quantity) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/ReturnToSupplier`, {
        PODCODE,
        POD_Qty: Quantity,
      });

      console.log("API Response:", response);
      getReceiving();

      toast.success("Successfully returned to supplier.");
    } catch (error) {
      console.error("Error fetching statement:", error);
      toast.error("Something went wrong.");
    }
  };

  const handleDownloadPDF1 = async (a) => {
    console.log(a);
    setDataSet(a);
  };

  const columns = React.useMemo(
    () => [
      {
        Header: () => <div style={{ textAlign: "center" }}>PO CODE</div>,
        accessor: "PODCODE",
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Vender Name</div>,
        accessor: "Vendor_Name",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        // if your table supports it
      },
      {
        Header: () => <div style={{ textAlign: "center" }}> Name</div>,

        accessor: "Name_EN",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        headerStyle: { textAlign: "left" },
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Date</div>,
        accessor: "Date",
        id: "Date", // important when using function accessor
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Crates</div>,
        accessor: "Crates",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>
            {formatTwoDecimals(value)}{" "}
            {/* <-- correctly calling the function */}
          </div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Quantity</div>,
        accessor: "Quantity",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Unit</div>,
        accessor: "Unit",
        Cell: ({ value }) => <div style={{ textAlign: "center" }}>{value}</div>,
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Cost</div>,
        accessor: "Cost",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>QTY / Crate</div>,

        accessor: "Qty/Crate",
        Cell: ({ value }) => (
          <div style={{ textAlign: "right" }}>{formatTwoDecimals(value)}</div>
        ),
      },
      {
        Header: () => <div style={{ textAlign: "center" }}>Status</div>,

        accessor: "Status",
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
        headerStyle: { textAlign: "left" },
      },

      {
        Header: () => <div style={{ textAlign: "center" }}>Actions</div>,
        accessor: (a) => (
          <>
            <button type="button" onClick={() => handleDownloadPDF1(a)}>
              <i
                className="mdi mdi-check me-2"
                type="button"
                data-bs-toggle="modal"
                data-bs-target="#exampleModal"
                style={{
                  width: "20px",
                  color: "#203764",
                  fontSize: "22px",
                  marginTop: "10px",
                }}
              />
            </button>

            <button
              type="button"
              onClick={() => handleDownloadPDF(a.PODCODE, a.Quantity)}
            >
              <i
                className="mdi mdi-package-variant"
                style={{
                  width: "20px",
                  color: "#203764",
                  fontSize: "22px",
                  marginTop: "10px",
                }}
              />
            </button>
          </>
        ),
        id: "Actions", // required when using function accessor
        Cell: ({ value }) => <div style={{ textAlign: "left" }}>{value}</div>,
      },
    ],
    []
  );
  // modal js

  // modal data here
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [color, setColor] = useState(false);

  const location = useLocation();
  // const navigate = useNavigate();
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [show, setShow] = useState(false);

  const [stock, setStock] = useState("");
  const { from } = location.state || {};
  console.log(from);
  const defaultState = {
    pod_code: from?.PODCODE,
    rcv_crate: from?.Crates,
    rcvd_qty: from?.Quantity,
    rcv_crate_weight: "",
    rcv_gross_weight: "",
    rcvd_unit_id: from?.Unit,
    user_id: localStorage.getItem("id"),
  };

  const [state, setState] = useState(defaultState);
  const [unitType, setUnitType] = useState([]);
  const closeIcon = () => {
    setShow(false);
    navigate("/receiving");
  };
  const getUnitType = () => {
    axios
      .get(`${API_BASE_URL}/getAllUnit`)
      .then((response) => {
        setUnitType(response.data.data || []);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    getUnitType();
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setState((prevState) => {
      return {
        ...prevState,
        [name]: value,
      };
    });
  };
  const addBank = () => {
    if (isButtonDisabled) return;
    setIsButtonDisabled(true);

    axios
      .post(`${API_BASE_URL}/addreceving`, {
        ...state,
        pod_code: dataSet?.PODCODE,
        pod_type_id: from?.pod_type_id,
        user_id: localStorage.getItem("id"),
      })
      .then((response) => {
        console.log(response);
        console.log(response.data.success, "Check response");
        toast.success("receiving Added Successfully");
        if (response.data.success && response.data.data == "1") {
          console.log(response.data.data.message);
          setStock(response.data.message);
          console.log(">>>>>>>>>>>>");
          setColor(true);
          // Open a modal here
          setShow(true);
        } else if (!response.data.success && response.data.data == "1") {
          console.log(response.data.data.message);
          setStock(response.data.message);
          console.log(">>>>>>>>>>>>");
          // Open a modal here
          setShow(true);
        } else if (response.data.success && response.data.data == "2") {
          toast.success("receiving Added Successfully", {
            autoClose: 1000,
            theme: "colored",
          });
          navigate("/receiving");
        }
      })
      .catch((error) => {
        console.log(error);
        setIsButtonDisabled(false); // Re-enable the button on error
      });
  };
  const dataClear = () => {
    setState({
      pod_code: "",
      rcv_crate: "",
      rcvd_qty: "",
      rcv_crate_weight: "",
      rcv_gross_weight: "",
      rcvd_unit_id: "",
      user_id: localStorage.getItem("id"), // keep user ID if needed
    });
    setIsButtonDisabled(false);
  };

  return (
    <>
      <Card title="Receive Management">
        <TableView columns={columns} data={data} />
      </Card>

      {/* Button trigger modal */}

      <div
        className="modal fade"
        id="exampleModal"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modalShipTo modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Operation / Accept Reciving
              </h1>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                onClick={dataClear}
              >
                <i class="mdi mdi-close"></i>
              </button>
            </div>
            <div className="modal-body">
              <main className="main-content">
                <div>
                  <div className="top-space-search-reslute mt-0">
                    <div className="tab-content">
                      <div
                        className="tab-pane active"
                        id="header"
                        role="tabpanel"
                      >
                        <div
                          id="datatable_wrapper"
                          className="information_dataTables dataTables_wrapper dt-bootstrap4"
                        >
                          <div className="d-flex exportPopupBtn"></div>
                          <div className="formCreate mt-0">
                            <form action="">
                              <div className="row">
                                <div className="form-group col-lg-3">
                                  <div className="parentPurchaseView">
                                    <div className="me-2">
                                      <strong>POD CODE:</strong>
                                    </div>

                                    <p>{dataSet?.PODCODE} </p>
                                  </div>
                                  <div className="parentPurchaseView">
                                    <div className="me-3">
                                      <strong>Name:</strong>
                                    </div>

                                    <p>{dataSet?.Name_EN} </p>
                                  </div>
                                  <div className="flex">
                                    <div className="parentPurchaseView">
                                      <div className="me-2">
                                        <strong>Quantity:</strong>
                                      </div>

                                      <p>
                                        {formatTwoDecimals(dataSet?.Quantity)}{" "}
                                      </p>
                                    </div>
                                    <div className="parentPurchaseView ms-3">
                                      <div className="me-2">
                                        <strong> unit:</strong>
                                      </div>

                                      <p>{dataSet?.Unit_Name} </p>
                                    </div>
                                    <div className="parentPurchaseView ms-3">
                                      <div className="me-2">
                                        <strong>Crates:</strong>
                                      </div>

                                      <p>
                                        {formatTwoDecimals(dataSet?.Crates)}{" "}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="row mt-2 inputMarginUnset">
                                <div className="form-group col-lg-6">
                                  <h6>Crate</h6>
                                  <input
                                    onChange={handleChange}
                                    type="text"
                                    name="rcv_crate"
                                    className="form-control"
                                    value={state.rcv_crate}
                                  />
                                </div>
                                <div className="form-group col-lg-6">
                                  <h6>Quantity</h6>
                                  <input
                                    onChange={handleChange}
                                    type="text"
                                    name="rcvd_qty"
                                    className="form-control"
                                    value={state.rcvd_qty}
                                  />
                                </div>
                                <div className="form-group col-lg-6">
                                  <h6>Crate Weight</h6>
                                  <input
                                    onChange={handleChange}
                                    type="text"
                                    name="rcv_crate_weight"
                                    className="form-control"
                                    value={state.rcv_crate_weight}
                                  />
                                </div>
                                <div className="form-group col-lg-6">
                                  <h6>Gross Weight</h6>
                                  <input
                                    onChange={handleChange}
                                    type="text"
                                    name="rcv_gross_weight"
                                    className="form-control"
                                    value={state.rcv_gross_weight}
                                  />
                                </div>
                                <div className="form-group col-lg-12">
                                  <h6>Unit</h6>
                                  <select
                                    onChange={handleChange}
                                    name="rcvd_unit_id"
                                    className="form-control"
                                    value={state.rcvd_unit_id}
                                  >
                                    <option value="">Select Unit</option>
                                    {unitType.map((unit) => (
                                      <option value={unit.ID}>
                                        {unit.Name_EN}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                      <div className=" ">
                        <button
                          onClick={addBank}
                          className="btn btn-primary"
                          disabled={isButtonDisabled}
                          type="submit"
                          name="signup"
                        >
                          Accept
                        </button>
                        <Link className="btn btn-danger" to="/receiving">
                          Cancel
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
                <Modal
                  className="modalError receiveModal"
                  show={show}
                  onHide={handleClose}
                >
                  <div className="modal-content">
                    <div
                      className="modal-header border-0"
                      style={{
                        backgroundColor: color ? "#2f423c" : "",
                      }}
                    >
                      <h1 className="modal-title fs-5" id="exampleModalLabel">
                        Receive Check
                      </h1>
                      <button
                        style={{ color: "#fff", fontSize: "30px" }}
                        type="button"
                        // onClick={() => setShow(false)}
                        onClick={closeIcon}
                      >
                        <i class="mdi mdi-close"></i>
                      </button>
                    </div>
                    <div
                      className="modal-body"
                      style={{
                        backgroundColor: color ? "#2f423c" : "",
                      }}
                    >
                      <div className="eanCheck errorMessage recheckReceive">
                        <p
                          style={{
                            backgroundColor: color ? "" : "#631f37",
                          }}
                        >
                          {stock.Message_EN ? stock.Message_EN : "NULL"}
                        </p>
                        <p
                          style={{
                            backgroundColor: color ? "" : "#631f37",
                          }}
                        >
                          {stock.Message_TH ? stock.Message_TH : "NULL"}
                        </p>
                        <div className="closeBtnRece">
                          <button onClick={closeIcon}>Close</button>
                        </div>
                      </div>
                    </div>
                    <div
                      className="modal-footer"
                      style={{
                        backgroundColor: color ? "#2f423c" : "",
                      }}
                    ></div>
                  </div>
                </Modal>
              </main>
            </div>
            <div className="modal-footer ps-0">
              {/* <button type="button" className="btn btn-primary">
                        Update
                      </button> */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Receiving;
